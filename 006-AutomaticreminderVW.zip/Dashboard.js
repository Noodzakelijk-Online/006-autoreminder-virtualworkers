import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Paper, 
  CircularProgress,
  Card,
  CardContent,
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Alert
} from '@mui/material';
import axios from 'axios';
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import WarningIcon from '@mui/icons-material/Warning';
import EmailIcon from '@mui/icons-material/Email';
import SmsIcon from '@mui/icons-material/Sms';
import CommentIcon from '@mui/icons-material/Comment';

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState(null);
  const [recentCards, setRecentCards] = useState([]);
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get notification stats
        const statsResponse = await axios.get('/api/notifications/status');
        setStats(statsResponse.data);
        
        // Get recent cards (this would be a separate endpoint in a real implementation)
        // For now, we'll simulate it
        setRecentCards([
          { id: 1, name: 'Website Redesign', status: 'responded', lastActivity: '2 hours ago' },
          { id: 2, name: 'Content Creation', status: 'pending', lastActivity: '1 day ago' },
          { id: 3, name: 'SEO Optimization', status: 'no_response', lastActivity: '3 days ago' },
          { id: 4, name: 'Social Media Campaign', status: 'pending', lastActivity: '12 hours ago' },
        ]);
        
        setError(null);
      } catch (err) {
        setError(err.response?.data?.message || 'Error fetching dashboard data');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  // Prepare data for charts
  const prepareResponseData = () => {
    if (!stats) return [];
    
    return [
      { name: 'Responded', value: stats.cardsWithResponses },
      { name: 'No Response', value: stats.totalCards - stats.cardsWithResponses }
    ];
  };
  
  const prepareReminderData = () => {
    if (!stats || !stats.reminderCounts) return [];
    
    return stats.reminderCounts.map(item => ({
      name: `Reminder ${item._id}`,
      count: item.count
    }));
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mt: 2 }}>
        {error}
      </Alert>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
      
      {/* Stats Overview */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              Total Cards
            </Typography>
            <Typography component="p" variant="h3">
              {stats?.totalCards || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Cards being monitored
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              Response Rate
            </Typography>
            <Typography component="p" variant="h3">
              {stats ? `${Math.round(stats.responseRate * 100)}%` : '0%'}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Cards with responses
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              Active Reminders
            </Typography>
            <Typography component="p" variant="h3">
              {stats?.cardsWithReminders || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Cards with active reminders
            </Typography>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 300 }}>
            <Typography variant="h6" gutterBottom>
              Response Status
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={prepareResponseData()}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {prepareResponseData().map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 300 }}>
            <Typography variant="h6" gutterBottom>
              Reminder Distribution
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={prepareReminderData()}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Recent Activity */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Recent Cards" />
            <Divider />
            <CardContent>
              <List>
                {recentCards.map((card) => (
                  <ListItem key={card.id} divider>
                    <ListItemIcon>
                      {card.status === 'responded' ? (
                        <CheckCircleIcon color="success" />
                      ) : card.status === 'no_response' ? (
                        <ErrorIcon color="error" />
                      ) : (
                        <WarningIcon color="warning" />
                      )}
                    </ListItemIcon>
                    <ListItemText 
                      primary={card.name} 
                      secondary={`Last activity: ${card.lastActivity}`} 
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Notification Channels" />
            <Divider />
            <CardContent>
              <List>
                <ListItem divider>
                  <ListItemIcon>
                    <CommentIcon />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Trello Comments" 
                    secondary={`${stats?.metrics?.notificationsSent?.trello || 0} sent`} 
                  />
                </ListItem>
                <ListItem divider>
                  <ListItemIcon>
                    <EmailIcon />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Email Notifications" 
                    secondary={`${stats?.metrics?.notificationsSent?.email || 0} sent`} 
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <SmsIcon />
                  </ListItemIcon>
                  <ListItemText 
                    primary="SMS/WhatsApp Messages" 
                    secondary={`${(stats?.metrics?.notificationsSent?.sms || 0) + (stats?.metrics?.notificationsSent?.whatsapp || 0)} sent`} 
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
