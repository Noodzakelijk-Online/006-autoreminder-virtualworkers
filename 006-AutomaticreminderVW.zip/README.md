# autoreminder-virtualworkers
Assigned in Trello to a card but not giving an update? This sends a reminder to virtual workers via email or sms to provide a statusupdate right away in the Trello card.
