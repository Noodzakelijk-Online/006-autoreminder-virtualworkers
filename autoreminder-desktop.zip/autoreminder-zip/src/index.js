import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { AuthProvider } from './context/AuthContext';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Templates from './pages/Templates';
import Configuration from './pages/Configuration';
import Reports from './pages/Reports';
import Logs from './pages/Logs';
import TrelloIntegration from './pages/TrelloIntegration';
import Notifications from './pages/Notifications';
import NotFound from './pages/NotFound';

// Components
import Layout from './components/layout/Layout';
import PrivateRoute from './components/auth/PrivateRoute';
import LoadingScreen from './components/common/LoadingScreen';
import UpdateNotification from './components/common/UpdateNotification';

// Create theme
const createAppTheme = (mode, accentColor) => {
  return createTheme({
    palette: {
      mode,
      primary: {
        main: accentColor || '#8A70FF',
      },
      secondary: {
        main: '#FF9F45',
      },
      success: {
        main: '#4CD964',
      },
      info: {
        main: '#3A7BFF',
      },
      background: {
        default: mode === 'dark' ? '#1A1F2E' : '#F5F7FA',
        paper: mode === 'dark' ? '#0F1521' : '#FFFFFF',
      },
      text: {
        primary: mode === 'dark' ? '#FFFFFF' : '#1A1F2E',
        secondary: mode === 'dark' ? '#B8C0D0' : '#6B7280',
      },
    },
    typography: {
      fontFamily: 'Inter, Arial, sans-serif',
      h1: {
        fontSize: '2rem',
        fontWeight: 600,
      },
      h2: {
        fontSize: '1.5rem',
        fontWeight: 600,
      },
      h3: {
        fontSize: '1.25rem',
        fontWeight: 500,
      },
      h4: {
        fontSize: '1.125rem',
        fontWeight: 500,
      },
      body1: {
        fontSize: '0.875rem',
      },
      body2: {
        fontSize: '0.75rem',
      },
    },
    shape: {
      borderRadius: 12,
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 24,
            textTransform: 'none',
            fontWeight: 500,
            padding: '8px 24px',
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 16,
            boxShadow: mode === 'dark' 
              ? '0 4px 20px rgba(0, 0, 0, 0.25)' 
              : '0 4px 20px rgba(0, 0, 0, 0.05)',
          },
        },
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            '& .MuiOutlinedInput-root': {
              borderRadius: 12,
            },
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: {
            borderRadius: 8,
          },
        },
      },
    },
  });
};

const App = () => {
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState({
    mode: 'dark',
    accentColor: '#8A70FF',
  });
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [updateDownloaded, setUpdateDownloaded] = useState(false);

  useEffect(() => {
    // Load configuration
    const loadConfig = async () => {
      try {
        const { success, config } = await window.api.getConfig();
        
        if (success && config) {
          setTheme({
            mode: config.theme || 'dark',
            accentColor: config.accentColor || '#8A70FF',
          });
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error loading configuration:', error);
        setLoading(false);
      }
    };

    loadConfig();

    // Listen for update events
    window.api.on('update-available', () => {
      setUpdateAvailable(true);
    });

    window.api.on('update-downloaded', () => {
      setUpdateDownloaded(true);
    });

    return () => {
      window.api.removeAllListeners('update-available');
      window.api.removeAllListeners('update-downloaded');
    };
  }, []);

  const handleThemeChange = (newTheme) => {
    setTheme(newTheme);
    
    // Save theme to configuration
    window.api.updateConfig({
      theme: newTheme.mode,
      accentColor: newTheme.accentColor,
    });
  };

  const handleInstallUpdate = () => {
    window.api.installUpdate();
  };

  if (loading) {
    return <LoadingScreen />;
  }

  const appTheme = createAppTheme(theme.mode, theme.accentColor);

  return (
    <ThemeProvider theme={appTheme}>
      <CssBaseline />
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<PrivateRoute><Layout onThemeChange={handleThemeChange} theme={theme} /></PrivateRoute>}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="templates" element={<Templates />} />
              <Route path="configuration" element={<Configuration onThemeChange={handleThemeChange} theme={theme} />} />
              <Route path="reports" element={<Reports />} />
              <Route path="logs" element={<Logs />} />
              <Route path="trello" element={<TrelloIntegration />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Router>
        
        {(updateAvailable || updateDownloaded) && (
          <UpdateNotification 
            available={updateAvailable} 
            downloaded={updateDownloaded} 
            onInstall={handleInstallUpdate} 
          />
        )}
      </AuthProvider>
    </ThemeProvider>
  );
};

const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App />);
