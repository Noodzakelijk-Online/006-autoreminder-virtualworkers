import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  Button, 
  CircularProgress,
  Tabs,
  Tab,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Tooltip,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { 
  Download as DownloadIcon,
  Refresh as RefreshIcon,
  Email as EmailIcon,
  Delete as DeleteIcon,
  CalendarToday as CalendarIcon,
  Share as ShareIcon
} from '@mui/icons-material';
import AlertBanner from '../../components/common/AlertBanner';
import ReportCard from '../../components/reports/ReportCard';
import DateRangePicker from '../../components/common/DateRangePicker';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import LineChart from '../../components/charts/LineChart';
import PieChart from '../../components/charts/PieChart';

const Reports = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [reportData, setReportData] = useState({
    reports: [],
    metrics: {
      cardsByDueDate: [],
      notificationsByChannel: {},
      responseRates: []
    }
  });
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    endDate: new Date()
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [formData, setFormData] = useState({
    reportType: 'weekly',
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    endDate: new Date(),
    recipients: [],
    includeCharts: true,
    includeDetails: true
  });

  useEffect(() => {
    fetchReportData();
  }, []);

  const fetchReportData = async () => {
    try {
      setLoading(true);
      
      // Get reports
      const reportsResponse = await window.api.getReports();
      
      if (!reportsResponse.success) {
        throw new Error('Failed to fetch reports');
      }
      
      // Get metrics
      const metricsResponse = await window.api.getReportMetrics(
        dateRange.startDate.toISOString(),
        dateRange.endDate.toISOString()
      );
      
      if (!metricsResponse.success) {
        throw new Error('Failed to fetch metrics');
      }
      
      setReportData({
        reports: reportsResponse.reports || [],
        metrics: metricsResponse.metrics || {
          cardsByDueDate: [],
          notificationsByChannel: {},
          responseRates: []
        }
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching report data:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleDateRangeChange = (newRange) => {
    setDateRange(newRange);
    
    // Fetch metrics for new date range
    fetchMetricsForDateRange(newRange.startDate, newRange.endDate);
  };

  const fetchMetricsForDateRange = async (startDate, endDate) => {
    try {
      setLoading(true);
      
      const response = await window.api.getReportMetrics(
        startDate.toISOString(),
        endDate.toISOString()
      );
      
      if (!response.success) {
        throw new Error('Failed to fetch metrics for date range');
      }
      
      setReportData(prev => ({
        ...prev,
        metrics: response.metrics || {
          cardsByDueDate: [],
          notificationsByChannel: {},
          responseRates: []
        }
      }));
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching metrics for date range:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleOpenDialog = () => {
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Update date range based on report type
    if (name === 'reportType') {
      let startDate = new Date();
      const endDate = new Date();
      
      switch (value) {
        case 'daily':
          startDate = new Date(endDate);
          startDate.setHours(0, 0, 0, 0);
          break;
        case 'weekly':
          startDate = new Date(endDate);
          startDate.setDate(startDate.getDate() - 7);
          break;
        case 'monthly':
          startDate = new Date(endDate);
          startDate.setMonth(startDate.getMonth() - 1);
          break;
        case 'quarterly':
          startDate = new Date(endDate);
          startDate.setMonth(startDate.getMonth() - 3);
          break;
        default:
          break;
      }
      
      setFormData(prev => ({
        ...prev,
        startDate,
        endDate
      }));
    }
  };

  const handleDateChange = (name, date) => {
    setFormData({
      ...formData,
      [name]: date
    });
  };

  const handleConfirmGenerate = () => {
    setConfirmDialogOpen(true);
  };

  const handleGenerateReport = async () => {
    try {
      setGenerating(true);
      setError(null);
      setSuccess(null);
      
      const response = await window.api.generateReport({
        type: formData.reportType,
        startDate: formData.startDate.toISOString(),
        endDate: formData.endDate.toISOString(),
        recipients: formData.recipients,
        options: {
          includeCharts: formData.includeCharts,
          includeDetails: formData.includeDetails
        }
      });
      
      if (!response.success) {
        throw new Error('Failed to generate report');
      }
      
      setSuccess('Report generated successfully');
      setDialogOpen(false);
      setConfirmDialogOpen(false);
      
      // Refresh reports
      await fetchReportData();
      
      setGenerating(false);
    } catch (error) {
      console.error('Error generating report:', error);
      setError(error.message);
      setConfirmDialogOpen(false);
      setGenerating(false);
    }
  };

  const handleDownloadReport = async (reportId) => {
    try {
      setLoading(true);
      
      const response = await window.api.downloadReport(reportId);
      
      if (!response.success) {
        throw new Error('Failed to download report');
      }
      
      // The backend should handle opening the file
      setLoading(false);
    } catch (error) {
      console.error('Error downloading report:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleEmailReport = async (reportId) => {
    try {
      setLoading(true);
      
      const response = await window.api.emailReport(reportId);
      
      if (!response.success) {
        throw new Error('Failed to email report');
      }
      
      setSuccess('Report emailed successfully');
      setLoading(false);
    } catch (error) {
      console.error('Error emailing report:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleDeleteReport = async (reportId) => {
    try {
      setLoading(true);
      
      const response = await window.api.deleteReport(reportId);
      
      if (!response.success) {
        throw new Error('Failed to delete report');
      }
      
      // Refresh reports
      await fetchReportData();
      
      setLoading(false);
    } catch (error) {
      console.error('Error deleting report:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  if (loading && reportData.reports.length === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      {success && <AlertBanner severity="success" message={success} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">Reports</Typography>
        <Button 
          variant="contained" 
          onClick={handleOpenDialog}
          disabled={generating}
        >
          Generate Report
        </Button>
      </Box>
      
      <Card sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Generated Reports" />
          <Tab label="Analytics Dashboard" />
        </Tabs>
        
        <Box sx={{ p: 3 }}>
          {/* Generated Reports Tab */}
          {tabValue === 0 && (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                View and manage your generated reports.
              </Typography>
              
              {reportData.reports.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 3 }}>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
                    No reports have been generated yet.
                  </Typography>
                  <Button 
                    variant="contained" 
                    onClick={handleOpenDialog}
                  >
                    Generate Your First Report
                  </Button>
                </Box>
              ) : (
                <TableContainer component={Paper} variant="outlined">
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Report Name</TableCell>
                        <TableCell>Type</TableCell>
                        <TableCell>Date Range</TableCell>
                        <TableCell>Generated On</TableCell>
                        <TableCell align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {reportData.reports.map(report => (
                        <TableRow key={report.id}>
                          <TableCell>{report.name}</TableCell>
                          <TableCell sx={{ textTransform: 'capitalize' }}>{report.type}</TableCell>
                          <TableCell>
                            {new Date(report.startDate).toLocaleDateString()} - {new Date(report.endDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>{new Date(report.generatedAt).toLocaleString()}</TableCell>
                          <TableCell align="right">
                            <Tooltip title="Download">
                              <IconButton onClick={() => handleDownloadReport(report.id)}>
                                <DownloadIcon />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Email">
                              <IconButton onClick={() => handleEmailReport(report.id)}>
                                <EmailIcon />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Delete">
                              <IconButton onClick={() => handleDeleteReport(report.id)}>
                                <DeleteIcon />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </>
          )}
          
          {/* Analytics Dashboard Tab */}
          {tabValue === 1 && (
            <>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h3">Analytics Dashboard</Typography>
                <DateRangePicker 
                  startDate={dateRange.startDate}
                  endDate={dateRange.endDate}
                  onChange={handleDateRangeChange}
                />
              </Box>
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={8}>
                  <Card variant="outlined" sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h4" sx={{ mb: 2 }}>Cards Due Over Time</Typography>
                    <Box sx={{ height: 300 }}>
                      <LineChart 
                        data={reportData.metrics.cardsByDueDate}
                        xKey="date"
                        yKey="count"
                        color={theme.palette.primary.main}
                      />
                    </Box>
                  </Card>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Card variant="outlined" sx={{ p: 2, height: '100%' }}>
                    <Typography variant="h4" sx={{ mb: 2 }}>Notifications by Channel</Typography>
                    <Box sx={{ height: 300 }}>
                      <PieChart 
                        data={Object.entries(reportData.metrics.notificationsByChannel).map(([key, value]) => ({
                          name: key,
                          value
                        }))}
                        nameKey="name"
                        valueKey="value"
                        colors={[
                          theme.palette.primary.main,
                          theme.palette.secondary.main,
                          theme.palette.success.main,
                          theme.palette.warning.main
                        ]}
                      />
                    </Box>
                  </Card>
                </Grid>
                
                <Grid item xs={12}>
                  <Card variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="h4" sx={{ mb: 2 }}>Response Rates</Typography>
                    <Box sx={{ height: 300 }}>
                      <LineChart 
                        data={reportData.metrics.responseRates}
                        xKey="date"
                        yKey="rate"
                        color={theme.palette.success.main}
                        unit="%"
                      />
                    </Box>
                  </Card>
                </Grid>
              </Grid>
            </>
          )}
        </Box>
      </Card>
      
      {/* Generate Report Dialog */}
      <Dialog 
        open={dialogOpen} 
        onClose={handleCloseDialog}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle>
          Generate Report
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel>Report Type</InputLabel>
                <Select
                  name="reportType"
                  value={formData.reportType}
                  onChange={handleInputChange}
                  label="Report Type"
                >
                  <MenuItem value="daily">Daily Report</MenuItem>
                  <MenuItem value="weekly">Weekly Report</MenuItem>
                  <MenuItem value="monthly">Monthly Report</MenuItem>
                  <MenuItem value="quarterly">Quarterly Report</MenuItem>
                  <MenuItem value="custom">Custom Date Range</MenuItem>
                </Select>
              </FormControl>
              
              {formData.reportType === 'custom' && (
                <Box sx={{ display: 'flex', gap: 2, mt: 2 }}>
                  <TextField
                    label="Start Date"
                    type="date"
                    value={formData.startDate.toISOString().split('T')[0]}
                    onChange={(e) => handleDateChange('startDate', new Date(e.target.value))}
                    InputLabelProps={{ shrink: true }}
                    fullWidth
                  />
                  
                  <TextField
                    label="End Date"
                    type="date"
                    value={formData.endDate.toISOString().split('T')[0]}
                    onChange={(e) => handleDateChange('endDate', new Date(e.target.value))}
                    InputLabelProps={{ shrink: true }}
                    fullWidth
                  />
                </Box>
              )}
              
              <TextField
                name="recipients"
                label="Email Recipients (Optional)"
                value={Array.isArray(formData.recipients) ? formData.recipients.join(', ') : ''}
                onChange={(e) => {
                  const recipients = e.target.value.split(',').map(email => email.trim()).filter(email => email);
                  setFormData({
                    ...formData,
                    recipients
                  });
                }}
                fullWidth
                margin="normal"
                helperText="Comma-separated list of email addresses"
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Typography variant="h4" sx={{ mb: 2 }}>Report Options</Typography>
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Include Charts</InputLabel>
                <Select
                  name="includeCharts"
                  value={formData.includeCharts}
                  onChange={(e) => setFormData({ ...formData, includeCharts: e.target.value })}
                  label="Include Charts"
                >
                  <MenuItem value={true}>Yes</MenuItem>
                  <MenuItem value={false}>No</MenuItem>
                </Select>
              </FormControl>
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Include Detailed Tables</InputLabel>
                <Select
                  name="includeDetails"
                  value={formData.includeDetails}
                  onChange={(e) => setFormData({ ...formData, includeDetails: e.target.value })}
                  label="Include Detailed Tables"
                >
                  <MenuItem value={true}>Yes</MenuItem>
                  <MenuItem value={false}>No</MenuItem>
                </Select>
              </FormControl>
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                Report will be generated as a PDF file and can be downloaded or emailed.
              </Typography>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleConfirmGenerate} 
            variant="contained"
            disabled={generating}
          >
            {generating ? <CircularProgress size={24} /> : 'Generate Report'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Confirm Generate Dialog */}
      <ConfirmDialog
        open={confirmDialogOpen}
        title="Generate Report"
        content={`Are you sure you want to generate a ${formData.reportType} report${formData.recipients.length > 0 ? ' and email it to the specified recipients' : ''}?`}
        onConfirm={handleGenerateReport}
        onCancel={() => setConfirmDialogOpen(false)}
        loading={generating}
      />
    </Box>
  );
};

export default Reports;
