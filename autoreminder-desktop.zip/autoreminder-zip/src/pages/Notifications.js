import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  Button, 
  CircularProgress,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { 
  Email as EmailIcon,
  Sms as SmsIcon,
  Comment as CommentIcon,
  WhatsApp as WhatsAppIcon,
  Send as SendIcon,
  Refresh as RefreshIcon,
  History as HistoryIcon
} from '@mui/icons-material';
import AlertBanner from '../../components/common/AlertBanner';
import NotificationCard from '../../components/notifications/NotificationCard';
import ConfirmDialog from '../../components/common/ConfirmDialog';

const Notifications = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [notificationData, setNotificationData] = useState({
    cards: [],
    templates: [],
    sentNotifications: [],
    stats: {
      totalSent: 0,
      byChannel: {}
    }
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);
  const [formData, setFormData] = useState({
    channels: ['trello'],
    message: '',
    templateId: ''
  });

  useEffect(() => {
    fetchNotificationData();
  }, []);

  const fetchNotificationData = async () => {
    try {
      setLoading(true);
      
      // Get cards
      const cardsResponse = await window.api.syncTrelloCards();
      
      if (!cardsResponse.success) {
        throw new Error('Failed to fetch cards');
      }
      
      // Get templates
      const templatesResponse = await window.api.getTemplates();
      
      if (!templatesResponse.success) {
        throw new Error('Failed to fetch templates');
      }
      
      // Get notification status
      const statusResponse = await window.api.getNotificationStatus();
      
      if (!statusResponse.success) {
        throw new Error('Failed to fetch notification status');
      }
      
      // Get sent notifications (this would be implemented in the backend)
      // For now, we'll use placeholder data
      const sentNotifications = [
        { id: 1, cardName: 'Update website content', channel: 'email', recipient: 'john@example.com', status: 'delivered', sentAt: new Date(Date.now() - 86400000) },
        { id: 2, cardName: 'Review Q3 metrics', channel: 'trello', recipient: 'Trello Board', status: 'delivered', sentAt: new Date(Date.now() - 172800000) },
        { id: 3, cardName: 'Finalize product roadmap', channel: 'sms', recipient: '+1234567890', status: 'failed', sentAt: new Date(Date.now() - 259200000) }
      ];
      
      setNotificationData({
        cards: cardsResponse.cards || [],
        templates: templatesResponse.templates || [],
        sentNotifications,
        stats: statusResponse.status?.metrics || { totalSent: 0, byChannel: {} }
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching notification data:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleOpenDialog = (card) => {
    setSelectedCard(card);
    
    // Find template for trello
    const trelloTemplate = notificationData.templates.find(t => t.type === 'trello');
    
    setFormData({
      channels: ['trello'],
      message: '',
      templateId: trelloTemplate?.id || ''
    });
    
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleChannelChange = (e) => {
    setFormData({
      ...formData,
      channels: e.target.value
    });
    
    // Update template based on selected channels
    if (e.target.value.length === 1) {
      const channel = e.target.value[0];
      const template = notificationData.templates.find(t => t.type === channel);
      
      if (template) {
        setFormData(prev => ({
          ...prev,
          templateId: template.id
        }));
      }
    }
  };

  const handleConfirmSend = () => {
    setConfirmDialogOpen(true);
  };

  const handleSendNotification = async () => {
    try {
      setSending(true);
      setError(null);
      setSuccess(null);
      
      const response = await window.api.sendNotification(
        selectedCard.id,
        formData.channels,
        formData.message || null
      );
      
      if (!response.success) {
        throw new Error('Failed to send notification');
      }
      
      setSuccess(`Notification sent successfully to ${formData.channels.join(', ')}`);
      setDialogOpen(false);
      setConfirmDialogOpen(false);
      
      // Refresh data
      await fetchNotificationData();
      
      setSending(false);
    } catch (error) {
      console.error('Error sending notification:', error);
      setError(error.message);
      setConfirmDialogOpen(false);
      setSending(false);
    }
  };

  const getChannelIcon = (channel) => {
    switch (channel) {
      case 'email':
        return <EmailIcon />;
      case 'sms':
        return <SmsIcon />;
      case 'trello':
        return <CommentIcon />;
      case 'whatsapp':
        return <WhatsAppIcon />;
      default:
        return <SendIcon />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'delivered':
        return 'success';
      case 'failed':
        return 'error';
      case 'pending':
        return 'warning';
      default:
        return 'default';
    }
  };

  if (loading && notificationData.cards.length === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      {success && <AlertBanner severity="success" message={success} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">Notifications</Typography>
        <Button 
          variant="outlined" 
          startIcon={<RefreshIcon />}
          onClick={fetchNotificationData}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>
      
      <Card sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Cards" />
          <Tab label="Sent Notifications" />
          <Tab label="Statistics" />
        </Tabs>
        
        <Box sx={{ p: 3 }}>
          {/* Cards Tab */}
          {tabValue === 0 && (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Select a card to send a manual notification. Automatic reminders will be sent based on your configuration.
              </Typography>
              
              {notificationData.cards.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 3 }}>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
                    No cards found with due dates.
                  </Typography>
                  <Button 
                    variant="outlined" 
                    startIcon={<RefreshIcon />}
                    onClick={fetchNotificationData}
                  >
                    Refresh Cards
                  </Button>
                </Box>
              ) : (
                <Grid container spacing={2}>
                  {notificationData.cards.map(card => (
                    <Grid item xs={12} sm={6} md={4} key={card.id}>
                      <NotificationCard 
                        card={card} 
                        onSendNotification={() => handleOpenDialog(card)}
                      />
                    </Grid>
                  ))}
                </Grid>
              )}
            </>
          )}
          
          {/* Sent Notifications Tab */}
          {tabValue === 1 && (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                History of notifications sent to Trello cards.
              </Typography>
              
              {notificationData.sentNotifications.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 3 }}>
                  <Typography variant="body1" color="text.secondary">
                    No notifications have been sent yet.
                  </Typography>
                </Box>
              ) : (
                <List>
                  {notificationData.sentNotifications.map(notification => (
                    <React.Fragment key={notification.id}>
                      <ListItem>
                        <ListItemAvatar>
                          <Avatar sx={{ bgcolor: theme.palette.primary.main }}>
                            {getChannelIcon(notification.channel)}
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText 
                          primary={notification.cardName}
                          secondary={`Sent to ${notification.recipient} on ${notification.sentAt.toLocaleString()}`}
                        />
                        <Chip 
                          label={notification.status}
                          color={getStatusColor(notification.status)}
                          size="small"
                        />
                      </ListItem>
                      <Divider variant="inset" component="li" />
                    </React.Fragment>
                  ))}
                </List>
              )}
            </>
          )}
          
          {/* Statistics Tab */}
          {tabValue === 2 && (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Notification statistics and metrics.
              </Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h3" color="primary" sx={{ mb: 1 }}>
                      {notificationData.stats.totalSent || 0}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Notifications Sent
                    </Typography>
                  </Card>
                </Grid>
                
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h3" color="primary" sx={{ mb: 1 }}>
                      {notificationData.stats.byChannel?.trello || 0}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Trello Comments
                    </Typography>
                  </Card>
                </Grid>
                
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h3" color="primary" sx={{ mb: 1 }}>
                      {notificationData.stats.byChannel?.email || 0}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Email Notifications
                    </Typography>
                  </Card>
                </Grid>
                
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h3" color="primary" sx={{ mb: 1 }}>
                      {(notificationData.stats.byChannel?.sms || 0) + (notificationData.stats.byChannel?.whatsapp || 0)}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      SMS/WhatsApp Messages
                    </Typography>
                  </Card>
                </Grid>
                
                <Grid item xs={12}>
                  <Card variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="h3" sx={{ mb: 2 }}>Channel Distribution</Typography>
                    
                    <Box sx={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap' }}>
                      {Object.entries(notificationData.stats.byChannel || {}).map(([channel, count]) => (
                        <Box key={channel} sx={{ textAlign: 'center', p: 2 }}>
                          <Avatar sx={{ bgcolor: theme.palette.primary.main, mx: 'auto', mb: 1 }}>
                            {getChannelIcon(channel)}
                          </Avatar>
                          <Typography variant="h4">{count}</Typography>
                          <Typography variant="body2" color="text.secondary" sx={{ textTransform: 'capitalize' }}>
                            {channel}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  </Card>
                </Grid>
              </Grid>
            </>
          )}
        </Box>
      </Card>
      
      {/* Send Notification Dialog */}
      <Dialog 
        open={dialogOpen} 
        onClose={handleCloseDialog}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>
          Send Notification
        </DialogTitle>
        <DialogContent dividers>
          {selectedCard && (
            <>
              <Typography variant="h4" sx={{ mb: 2 }}>
                {selectedCard.name}
              </Typography>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Due: {new Date(selectedCard.due_date).toLocaleString()}
              </Typography>
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Notification Channels</InputLabel>
                <Select
                  name="channels"
                  multiple
                  value={formData.channels}
                  onChange={handleChannelChange}
                  label="Notification Channels"
                  renderValue={(selected) => (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip 
                          key={value} 
                          label={value} 
                          size="small"
                          icon={getChannelIcon(value)}
                        />
                      ))}
                    </Box>
                  )}
                >
                  <MenuItem value="trello">Trello Comment</MenuItem>
                  <MenuItem value="email">Email</MenuItem>
                  <MenuItem value="sms">SMS</MenuItem>
                  <MenuItem value="whatsapp">WhatsApp</MenuItem>
                </Select>
              </FormControl>
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Use Template</InputLabel>
                <Select
                  name="templateId"
                  value={formData.templateId}
                  onChange={handleInputChange}
                  label="Use Template"
                >
                  <MenuItem value="">Custom Message</MenuItem>
                  {notificationData.templates
                    .filter(template => formData.channels.includes(template.type))
                    .map(template => (
                      <MenuItem key={template.id} value={template.id}>
                        {template.name}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
              
              {!formData.templateId && (
                <TextField
                  name="message"
                  label="Custom Message"
                  value={formData.message}
                  onChange={handleInputChange}
                  fullWidth
                  margin="normal"
                  multiline
                  rows={4}
                  required
                />
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleConfirmSend} 
            variant="contained"
            disabled={!formData.channels.length || (!formData.templateId && !formData.message)}
            startIcon={<SendIcon />}
          >
            Send Notification
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Confirm Send Dialog */}
      <ConfirmDialog
        open={confirmDialogOpen}
        title="Send Notification"
        content={`Are you sure you want to send a notification to ${selectedCard?.name} via ${formData.channels.join(', ')}?`}
        onConfirm={handleSendNotification}
        onCancel={() => setConfirmDialogOpen(false)}
        loading={sending}
      />
    </Box>
  );
};

export default Notifications;
