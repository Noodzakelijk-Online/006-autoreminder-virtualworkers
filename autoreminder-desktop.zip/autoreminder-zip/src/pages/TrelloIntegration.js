import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  Button, 
  CircularProgress,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  Chip,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { 
  Refresh as RefreshIcon,
  Link as LinkIcon,
  Add as AddIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';
import AlertBanner from '../../components/common/AlertBanner';
import BoardCard from '../../components/trello/BoardCard';
import CardList from '../../components/trello/CardList';
import TrelloAuthButton from '../../components/trello/TrelloAuthButton';
import ConfirmDialog from '../../components/common/ConfirmDialog';

const TrelloIntegration = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [trelloData, setTrelloData] = useState({
    isAuthenticated: false,
    boards: [],
    selectedBoard: null,
    cards: [],
    listNames: ['To Do', 'Doing', 'Done']
  });
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [listNameInput, setListNameInput] = useState('');

  useEffect(() => {
    checkTrelloAuth();
  }, []);

  const checkTrelloAuth = async () => {
    try {
      setLoading(true);
      
      // Check if Trello is authenticated
      const authResponse = await window.api.getTrelloCredentials();
      
      if (authResponse.success && authResponse.credentials) {
        setTrelloData(prev => ({
          ...prev,
          isAuthenticated: true
        }));
        
        // Fetch boards
        await fetchTrelloBoards();
      } else {
        setTrelloData(prev => ({
          ...prev,
          isAuthenticated: false
        }));
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error checking Trello authentication:', error);
      setError('Failed to check Trello authentication status');
      setLoading(false);
    }
  };

  const handleTrelloAuth = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await window.api.trelloAuth();
      
      if (response.success) {
        setTrelloData(prev => ({
          ...prev,
          isAuthenticated: true
        }));
        
        // Fetch boards
        await fetchTrelloBoards();
        
        setSuccess('Successfully authenticated with Trello');
      } else {
        throw new Error('Failed to authenticate with Trello');
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error authenticating with Trello:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const fetchTrelloBoards = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.getTrelloBoards();
      
      if (response.success) {
        setTrelloData(prev => ({
          ...prev,
          boards: response.boards || []
        }));
      } else {
        throw new Error('Failed to fetch Trello boards');
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching Trello boards:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleBoardSelect = async (boardId) => {
    try {
      setLoading(true);
      
      // Find the selected board
      const selectedBoard = trelloData.boards.find(board => board.id === boardId);
      
      if (!selectedBoard) {
        throw new Error('Board not found');
      }
      
      // Fetch cards for the selected board
      const response = await window.api.getTrelloCards(boardId, trelloData.listNames);
      
      if (response.success) {
        setTrelloData(prev => ({
          ...prev,
          selectedBoard,
          cards: response.cards || []
        }));
      } else {
        throw new Error('Failed to fetch Trello cards');
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error selecting Trello board:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleSyncCards = async () => {
    try {
      setSyncing(true);
      setError(null);
      setSuccess(null);
      
      const response = await window.api.syncTrelloCards();
      
      if (response.success) {
        // Refresh cards if a board is selected
        if (trelloData.selectedBoard) {
          await handleBoardSelect(trelloData.selectedBoard.id);
        }
        
        setSuccess('Successfully synced Trello cards');
      } else {
        throw new Error('Failed to sync Trello cards');
      }
      
      setSyncing(false);
    } catch (error) {
      console.error('Error syncing Trello cards:', error);
      setError(error.message);
      setSyncing(false);
    }
  };

  const handleAddListName = () => {
    if (listNameInput.trim() === '') return;
    
    setTrelloData(prev => ({
      ...prev,
      listNames: [...prev.listNames, listNameInput.trim()]
    }));
    
    setListNameInput('');
    
    // Refresh cards if a board is selected
    if (trelloData.selectedBoard) {
      handleBoardSelect(trelloData.selectedBoard.id);
    }
  };

  const handleRemoveListName = (index) => {
    setTrelloData(prev => ({
      ...prev,
      listNames: prev.listNames.filter((_, i) => i !== index)
    }));
    
    // Refresh cards if a board is selected
    if (trelloData.selectedBoard) {
      handleBoardSelect(trelloData.selectedBoard.id);
    }
  };

  const handleConfirmSync = () => {
    setConfirmDialogOpen(true);
  };

  if (loading && !trelloData.isAuthenticated) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      {success && <AlertBanner severity="success" message={success} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">Trello Integration</Typography>
        {trelloData.isAuthenticated && (
          <Button 
            variant="contained" 
            startIcon={<RefreshIcon />}
            onClick={handleConfirmSync}
            disabled={syncing}
          >
            {syncing ? <CircularProgress size={24} /> : 'Sync Cards'}
          </Button>
        )}
      </Box>
      
      {!trelloData.isAuthenticated ? (
        <Card sx={{ p: 3, textAlign: 'center' }}>
          <Typography variant="h3" sx={{ mb: 3 }}>Connect to Trello</Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            To use AutoReminder, you need to connect to your Trello account.
            This will allow the application to access your boards and cards.
          </Typography>
          <TrelloAuthButton onClick={handleTrelloAuth} />
        </Card>
      ) : (
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Card sx={{ p: 3, height: '100%' }}>
              <Typography variant="h3" sx={{ mb: 3 }}>Trello Boards</Typography>
              
              {trelloData.boards.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 3 }}>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
                    No boards found in your Trello account.
                  </Typography>
                  <Button 
                    variant="outlined" 
                    startIcon={<RefreshIcon />}
                    onClick={fetchTrelloBoards}
                  >
                    Refresh Boards
                  </Button>
                </Box>
              ) : (
                <Grid container spacing={2}>
                  {trelloData.boards.map(board => (
                    <Grid item xs={12} key={board.id}>
                      <BoardCard 
                        board={board} 
                        isSelected={trelloData.selectedBoard?.id === board.id}
                        onClick={() => handleBoardSelect(board.id)}
                      />
                    </Grid>
                  ))}
                </Grid>
              )}
            </Card>
          </Grid>
          
          <Grid item xs={12} md={8}>
            <Card sx={{ p: 3, mb: 3 }}>
              <Typography variant="h3" sx={{ mb: 3 }}>List Configuration</Typography>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Specify which Trello lists to monitor for cards with due dates.
                Only cards in these lists will be included in reminders.
              </Typography>
              
              <Box sx={{ display: 'flex', mb: 2 }}>
                <TextField
                  label="List Name"
                  value={listNameInput}
                  onChange={(e) => setListNameInput(e.target.value)}
                  fullWidth
                  sx={{ mr: 2 }}
                />
                <Button 
                  variant="contained" 
                  startIcon={<AddIcon />}
                  onClick={handleAddListName}
                  disabled={!listNameInput.trim()}
                >
                  Add
                </Button>
              </Box>
              
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {trelloData.listNames.map((listName, index) => (
                  <Chip 
                    key={index}
                    label={listName}
                    onDelete={() => handleRemoveListName(index)}
                    color="primary"
                    variant="outlined"
                  />
                ))}
              </Box>
            </Card>
            
            {trelloData.selectedBoard ? (
              <Card sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ mb: 3 }}>
                  Cards in {trelloData.selectedBoard.name}
                </Typography>
                
                {trelloData.cards.length === 0 ? (
                  <Box sx={{ textAlign: 'center', py: 3 }}>
                    <Typography variant="body1" color="text.secondary">
                      No cards with due dates found in the selected lists.
                    </Typography>
                  </Box>
                ) : (
                  <CardList cards={trelloData.cards} />
                )}
              </Card>
            ) : (
              <Card sx={{ p: 3, textAlign: 'center' }}>
                <Typography variant="body1" color="text.secondary">
                  Select a board to view cards.
                </Typography>
              </Card>
            )}
          </Grid>
        </Grid>
      )}
      
      {/* Confirm Sync Dialog */}
      <ConfirmDialog
        open={confirmDialogOpen}
        title="Sync Trello Cards"
        content="This will sync all cards from your Trello boards and update the local database. Continue?"
        onConfirm={() => {
          setConfirmDialogOpen(false);
          handleSyncCards();
        }}
        onCancel={() => setConfirmDialogOpen(false)}
      />
    </Box>
  );
};

export default TrelloIntegration;
