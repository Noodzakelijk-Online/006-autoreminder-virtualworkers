import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  Button, 
  CircularProgress,
  Tabs,
  Tab,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Paper,
  Chip,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { 
  Refresh as RefreshIcon,
  Delete as DeleteIcon,
  FilterList as FilterIcon,
  Download as DownloadIcon,
  Error as ErrorIcon,
  Info as InfoIcon,
  Warning as WarningIcon,
  CheckCircle as SuccessIcon
} from '@mui/icons-material';
import AlertBanner from '../../components/common/AlertBanner';
import DateRangePicker from '../../components/common/DateRangePicker';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import LogDetailDialog from '../../components/logs/LogDetailDialog';

const Logs = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [logData, setLogData] = useState({
    logs: [],
    totalCount: 0
  });
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    endDate: new Date()
  });
  const [filters, setFilters] = useState({
    level: 'all',
    source: 'all',
    search: ''
  });
  const [pagination, setPagination] = useState({
    page: 0,
    rowsPerPage: 10
  });
  const [filterDialogOpen, setFilterDialogOpen] = useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [logDetailDialogOpen, setLogDetailDialogOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState(null);

  useEffect(() => {
    fetchLogs();
  }, [pagination.page, pagination.rowsPerPage, dateRange, filters]);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.getLogs({
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
        level: filters.level !== 'all' ? filters.level : undefined,
        source: filters.source !== 'all' ? filters.source : undefined,
        search: filters.search || undefined,
        page: pagination.page,
        limit: pagination.rowsPerPage
      });
      
      if (!response.success) {
        throw new Error('Failed to fetch logs');
      }
      
      setLogData({
        logs: response.logs || [],
        totalCount: response.totalCount || 0
      });
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching logs:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
    
    // Set filters based on tab
    switch (newValue) {
      case 0: // All logs
        setFilters({
          ...filters,
          level: 'all'
        });
        break;
      case 1: // Errors
        setFilters({
          ...filters,
          level: 'error'
        });
        break;
      case 2: // Warnings
        setFilters({
          ...filters,
          level: 'warning'
        });
        break;
      case 3: // Info
        setFilters({
          ...filters,
          level: 'info'
        });
        break;
      default:
        break;
    }
  };

  const handleDateRangeChange = (newRange) => {
    setDateRange(newRange);
    setPagination({
      ...pagination,
      page: 0
    });
  };

  const handleChangePage = (event, newPage) => {
    setPagination({
      ...pagination,
      page: newPage
    });
  };

  const handleChangeRowsPerPage = (event) => {
    setPagination({
      page: 0,
      rowsPerPage: parseInt(event.target.value, 10)
    });
  };

  const handleOpenFilterDialog = () => {
    setFilterDialogOpen(true);
  };

  const handleCloseFilterDialog = () => {
    setFilterDialogOpen(false);
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
  };

  const handleApplyFilters = () => {
    setPagination({
      ...pagination,
      page: 0
    });
    setFilterDialogOpen(false);
  };

  const handleResetFilters = () => {
    setFilters({
      level: 'all',
      source: 'all',
      search: ''
    });
    setPagination({
      ...pagination,
      page: 0
    });
    setFilterDialogOpen(false);
  };

  const handleOpenLogDetail = (log) => {
    setSelectedLog(log);
    setLogDetailDialogOpen(true);
  };

  const handleCloseLogDetail = () => {
    setLogDetailDialogOpen(false);
  };

  const handleConfirmClearLogs = () => {
    setConfirmDialogOpen(true);
  };

  const handleClearLogs = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.clearLogs({
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
        level: filters.level !== 'all' ? filters.level : undefined,
        source: filters.source !== 'all' ? filters.source : undefined
      });
      
      if (!response.success) {
        throw new Error('Failed to clear logs');
      }
      
      setSuccess('Logs cleared successfully');
      setConfirmDialogOpen(false);
      
      // Refresh logs
      await fetchLogs();
      
      setLoading(false);
    } catch (error) {
      console.error('Error clearing logs:', error);
      setError(error.message);
      setConfirmDialogOpen(false);
      setLoading(false);
    }
  };

  const handleExportLogs = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.exportLogs({
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
        level: filters.level !== 'all' ? filters.level : undefined,
        source: filters.source !== 'all' ? filters.source : undefined,
        search: filters.search || undefined
      });
      
      if (!response.success) {
        throw new Error('Failed to export logs');
      }
      
      setSuccess('Logs exported successfully');
      setLoading(false);
    } catch (error) {
      console.error('Error exporting logs:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const getLevelIcon = (level) => {
    switch (level) {
      case 'error':
        return <ErrorIcon color="error" />;
      case 'warning':
        return <WarningIcon color="warning" />;
      case 'info':
        return <InfoIcon color="info" />;
      case 'success':
        return <SuccessIcon color="success" />;
      default:
        return <InfoIcon color="info" />;
    }
  };

  const getLevelColor = (level) => {
    switch (level) {
      case 'error':
        return 'error';
      case 'warning':
        return 'warning';
      case 'info':
        return 'info';
      case 'success':
        return 'success';
      default:
        return 'default';
    }
  };

  if (loading && logData.logs.length === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      {success && <AlertBanner severity="success" message={success} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">System Logs</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<FilterIcon />}
            onClick={handleOpenFilterDialog}
            sx={{ mr: 1 }}
          >
            Filters
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            onClick={handleExportLogs}
            sx={{ mr: 1 }}
          >
            Export
          </Button>
          <Button 
            variant="outlined" 
            color="error"
            startIcon={<DeleteIcon />}
            onClick={handleConfirmClearLogs}
          >
            Clear Logs
          </Button>
        </Box>
      </Box>
      
      <Card sx={{ mb: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab label="All Logs" />
            <Tab label="Errors" />
            <Tab label="Warnings" />
            <Tab label="Info" />
          </Tabs>
          
          <DateRangePicker 
            startDate={dateRange.startDate}
            endDate={dateRange.endDate}
            onChange={handleDateRangeChange}
          />
        </Box>
        
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Level</TableCell>
                <TableCell>Timestamp</TableCell>
                <TableCell>Source</TableCell>
                <TableCell>Message</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {logData.logs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">
                    <Typography variant="body1" color="text.secondary" sx={{ py: 3 }}>
                      No logs found for the selected filters.
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                logData.logs.map(log => (
                  <TableRow key={log.id} hover onClick={() => handleOpenLogDetail(log)} sx={{ cursor: 'pointer' }}>
                    <TableCell>
                      <Chip 
                        icon={getLevelIcon(log.level)} 
                        label={log.level} 
                        color={getLevelColor(log.level)}
                        size="small"
                        sx={{ textTransform: 'capitalize' }}
                      />
                    </TableCell>
                    <TableCell>{new Date(log.timestamp).toLocaleString()}</TableCell>
                    <TableCell>{log.source}</TableCell>
                    <TableCell>
                      <Typography variant="body2" noWrap sx={{ maxWidth: 400 }}>
                        {log.message}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="View Details">
                        <IconButton onClick={(e) => {
                          e.stopPropagation();
                          handleOpenLogDetail(log);
                        }}>
                          <InfoIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        <TablePagination
          component="div"
          count={logData.totalCount}
          page={pagination.page}
          onPageChange={handleChangePage}
          rowsPerPage={pagination.rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          rowsPerPageOptions={[10, 25, 50, 100]}
        />
      </Card>
      
      {/* Filter Dialog */}
      <Dialog 
        open={filterDialogOpen} 
        onClose={handleCloseFilterDialog}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>
          Filter Logs
        </DialogTitle>
        <DialogContent dividers>
          <FormControl fullWidth margin="normal">
            <InputLabel>Log Level</InputLabel>
            <Select
              name="level"
              value={filters.level}
              onChange={handleFilterChange}
              label="Log Level"
            >
              <MenuItem value="all">All Levels</MenuItem>
              <MenuItem value="error">Error</MenuItem>
              <MenuItem value="warning">Warning</MenuItem>
              <MenuItem value="info">Info</MenuItem>
              <MenuItem value="success">Success</MenuItem>
            </Select>
          </FormControl>
          
          <FormControl fullWidth margin="normal">
            <InputLabel>Source</InputLabel>
            <Select
              name="source"
              value={filters.source}
              onChange={handleFilterChange}
              label="Source"
            >
              <MenuItem value="all">All Sources</MenuItem>
              <MenuItem value="trello">Trello</MenuItem>
              <MenuItem value="email">Email</MenuItem>
              <MenuItem value="sms">SMS</MenuItem>
              <MenuItem value="whatsapp">WhatsApp</MenuItem>
              <MenuItem value="scheduler">Scheduler</MenuItem>
              <MenuItem value="database">Database</MenuItem>
              <MenuItem value="system">System</MenuItem>
            </Select>
          </FormControl>
          
          <TextField
            name="search"
            label="Search"
            value={filters.search}
            onChange={handleFilterChange}
            fullWidth
            margin="normal"
            placeholder="Search in log messages..."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleResetFilters}>Reset</Button>
          <Button onClick={handleCloseFilterDialog}>Cancel</Button>
          <Button onClick={handleApplyFilters} variant="contained">Apply Filters</Button>
        </DialogActions>
      </Dialog>
      
      {/* Log Detail Dialog */}
      {selectedLog && (
        <LogDetailDialog
          open={logDetailDialogOpen}
          log={selectedLog}
          onClose={handleCloseLogDetail}
        />
      )}
      
      {/* Confirm Clear Logs Dialog */}
      <ConfirmDialog
        open={confirmDialogOpen}
        title="Clear Logs"
        content={`Are you sure you want to clear all ${filters.level !== 'all' ? filters.level + ' ' : ''}logs${filters.source !== 'all' ? ' from ' + filters.source : ''}? This action cannot be undone.`}
        onConfirm={handleClearLogs}
        onCancel={() => setConfirmDialogOpen(false)}
        loading={loading}
      />
    </Box>
  );
};

export default Logs;
