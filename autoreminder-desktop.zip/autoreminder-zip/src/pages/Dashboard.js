import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  Button, 
  CircularProgress,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement,
  BarElement,
  ArcElement,
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import DashboardCard from '../../components/dashboard/DashboardCard';
import ActivityList from '../../components/dashboard/ActivityList';
import ReminderTimeline from '../../components/dashboard/ReminderTimeline';
import AlertBanner from '../../components/common/AlertBanner';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const Dashboard = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dashboardData, setDashboardData] = useState({
    totalCards: 0,
    responseRate: 0,
    activeReminders: 0,
    notificationsSent: 0,
    activityData: [],
    reminderDistribution: [],
    channelDistribution: {},
    recentActivity: [],
    upcomingReminders: []
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get notification status
        const notificationStatus = await window.api.getNotificationStatus();
        
        if (!notificationStatus.success) {
          throw new Error('Failed to fetch notification status');
        }
        
        // Get logs for recent activity
        const logsResponse = await window.api.getLogs(1, 10, { type: 'notification' });
        
        if (!logsResponse.success) {
          throw new Error('Failed to fetch logs');
        }
        
        // Get upcoming reminders (this would be implemented in the backend)
        // For now, we'll use placeholder data
        const upcomingReminders = [
          { id: 1, cardName: 'Update website content', dueDate: new Date(Date.now() + 86400000), boardName: 'Marketing' },
          { id: 2, cardName: 'Review Q3 metrics', dueDate: new Date(Date.now() + 172800000), boardName: 'Management' },
          { id: 3, cardName: 'Finalize product roadmap', dueDate: new Date(Date.now() + 259200000), boardName: 'Product' }
        ];
        
        // Get activity data for chart
        const logStats = await window.api.getLogStats();
        
        if (!logStats.success) {
          throw new Error('Failed to fetch log statistics');
        }
        
        // Process data
        const status = notificationStatus.status;
        const reminderCounts = status.reminderCounts || [];
        const notificationsByChannel = status.metrics?.notificationsSent || {};
        
        // Format data for charts
        const activityData = logStats.stats.byDay.map(day => ({
          date: day.date,
          count: day.count
        }));
        
        setDashboardData({
          totalCards: status.totalCards || 0,
          responseRate: status.responseRate || 0,
          activeReminders: status.cardsWithReminders || 0,
          notificationsSent: Object.values(notificationsByChannel).reduce((a, b) => a + b, 0),
          activityData,
          reminderDistribution: reminderCounts,
          channelDistribution: notificationsByChannel,
          recentActivity: logsResponse.logs || [],
          upcomingReminders
        });
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setError(error.message);
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  // Prepare chart data
  const activityChartData = {
    labels: dashboardData.activityData.map(item => item.date),
    datasets: [
      {
        label: 'Activity',
        data: dashboardData.activityData.map(item => item.count),
        fill: true,
        backgroundColor: `rgba(138, 112, 255, 0.2)`,
        borderColor: theme.palette.primary.main,
        tension: 0.4
      }
    ]
  };

  const channelChartData = {
    labels: Object.keys(dashboardData.channelDistribution),
    datasets: [
      {
        data: Object.values(dashboardData.channelDistribution),
        backgroundColor: [
          theme.palette.primary.main,
          theme.palette.secondary.main,
          theme.palette.success.main,
          theme.palette.info.main
        ],
        borderWidth: 0
      }
    ]
  };

  const reminderChartData = {
    labels: dashboardData.reminderDistribution.map(item => `Day ${item._id}`),
    datasets: [
      {
        label: 'Reminders',
        data: dashboardData.reminderDistribution.map(item => item.count),
        backgroundColor: theme.palette.primary.main
      }
    ]
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <AlertBanner severity="error" message={error} />;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h1" sx={{ mb: 3 }}>Dashboard</Typography>
      
      {/* Key Metrics */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Total Cards" 
            value={dashboardData.totalCards} 
            icon="card" 
            color={theme.palette.primary.main} 
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Response Rate" 
            value={`${Math.round(dashboardData.responseRate * 100)}%`} 
            icon="rate" 
            color={theme.palette.success.main} 
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Active Reminders" 
            value={dashboardData.activeReminders} 
            icon="reminder" 
            color={theme.palette.secondary.main} 
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Notifications Sent" 
            value={dashboardData.notificationsSent} 
            icon="notification" 
            color={theme.palette.info.main} 
          />
        </Grid>
      </Grid>
      
      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={8}>
          <Card sx={{ p: 3, height: '100%' }}>
            <Typography variant="h3" sx={{ mb: 2 }}>Activity Over Time</Typography>
            <Box sx={{ height: 300 }}>
              <Line 
                data={activityChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: true,
                      grid: {
                        color: theme.palette.mode === 'dark' 
                          ? 'rgba(255, 255, 255, 0.1)' 
                          : 'rgba(0, 0, 0, 0.1)'
                      }
                    },
                    x: {
                      grid: {
                        display: false
                      }
                    }
                  },
                  plugins: {
                    legend: {
                      display: false
                    }
                  }
                }} 
              />
            </Box>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Grid container spacing={3} direction="column" sx={{ height: '100%' }}>
            <Grid item xs={6}>
              <Card sx={{ p: 3, height: '100%' }}>
                <Typography variant="h3" sx={{ mb: 2 }}>Notification Channels</Typography>
                <Box sx={{ height: 150, display: 'flex', justifyContent: 'center' }}>
                  <Doughnut 
                    data={channelChartData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: 'right',
                          labels: {
                            color: theme.palette.text.primary
                          }
                        }
                      }
                    }} 
                  />
                </Box>
              </Card>
            </Grid>
            <Grid item xs={6}>
              <Card sx={{ p: 3, height: '100%' }}>
                <Typography variant="h3" sx={{ mb: 2 }}>Reminder Distribution</Typography>
                <Box sx={{ height: 150 }}>
                  <Bar 
                    data={reminderChartData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        y: {
                          beginAtZero: true,
                          grid: {
                            color: theme.palette.mode === 'dark' 
                              ? 'rgba(255, 255, 255, 0.1)' 
                              : 'rgba(0, 0, 0, 0.1)'
                          }
                        },
                        x: {
                          grid: {
                            display: false
                          }
                        }
                      },
                      plugins: {
                        legend: {
                          display: false
                        }
                      }
                    }} 
                  />
                </Box>
              </Card>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      
      {/* Activity and Reminders */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card sx={{ p: 3, height: '100%' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h3">Recent Activity</Typography>
              <Button variant="outlined" size="small">View All</Button>
            </Box>
            <ActivityList activities={dashboardData.recentActivity} />
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card sx={{ p: 3, height: '100%' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h3">Upcoming Reminders</Typography>
              <Button variant="outlined" size="small">View All</Button>
            </Box>
            <ReminderTimeline reminders={dashboardData.upcomingReminders} />
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
