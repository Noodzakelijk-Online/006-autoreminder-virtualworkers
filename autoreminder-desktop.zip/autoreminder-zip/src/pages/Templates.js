import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  TextField, 
  Button, 
  CircularProgress,
  Tabs,
  Tab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import AlertBanner from '../../components/common/AlertBanner';
import TemplateEditor from '../../components/templates/TemplateEditor';
import TemplatePreview from '../../components/templates/TemplatePreview';
import ConfirmDialog from '../../components/common/ConfirmDialog';

const Templates = () => {
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'email',
    subject: '',
    content: ''
  });

  // Template types
  const templateTypes = [
    { value: 'email', label: 'Email' },
    { value: 'trello', label: 'Trello Comment' },
    { value: 'sms', label: 'SMS' },
    { value: 'whatsapp', label: 'WhatsApp' }
  ];

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.getTemplates();
      
      if (!response.success) {
        throw new Error('Failed to fetch templates');
      }
      
      setTemplates(response.templates || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching templates:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleOpenDialog = (template = null) => {
    if (template) {
      setIsEditing(true);
      setCurrentTemplate(template);
      setFormData({
        name: template.name,
        type: template.type,
        subject: template.subject || '',
        content: template.content
      });
    } else {
      setIsEditing(false);
      setCurrentTemplate(null);
      setFormData({
        name: '',
        type: 'email',
        subject: '',
        content: ''
      });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleContentChange = (content) => {
    setFormData({
      ...formData,
      content
    });
  };

  const handleSaveTemplate = async () => {
    try {
      setLoading(true);
      
      let response;
      
      if (isEditing && currentTemplate) {
        response = await window.api.updateTemplate(currentTemplate.id, formData);
      } else {
        response = await window.api.createTemplate(formData);
      }
      
      if (!response.success) {
        throw new Error(`Failed to ${isEditing ? 'update' : 'create'} template`);
      }
      
      await fetchTemplates();
      setDialogOpen(false);
      setLoading(false);
    } catch (error) {
      console.error('Error saving template:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleDeleteClick = (template) => {
    setCurrentTemplate(template);
    setConfirmDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    try {
      setLoading(true);
      
      const response = await window.api.deleteTemplate(currentTemplate.id);
      
      if (!response.success) {
        throw new Error('Failed to delete template');
      }
      
      await fetchTemplates();
      setConfirmDialogOpen(false);
      setLoading(false);
    } catch (error) {
      console.error('Error deleting template:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const filteredTemplates = templates.filter(template => {
    if (tabValue === 0) return true;
    return template.type === templateTypes[tabValue - 1].value;
  });

  if (loading && templates.length === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">Notification Templates</Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Create Template
        </Button>
      </Box>
      
      <Card sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="All Templates" />
          {templateTypes.map((type, index) => (
            <Tab key={type.value} label={type.label} />
          ))}
        </Tabs>
        
        <Box sx={{ p: 3 }}>
          {filteredTemplates.length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="body1" color="text.secondary">
                No templates found. Create your first template to get started.
              </Typography>
              <Button 
                variant="contained" 
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                sx={{ mt: 2 }}
              >
                Create Template
              </Button>
            </Box>
          ) : (
            <Grid container spacing={3}>
              {filteredTemplates.map(template => (
                <Grid item xs={12} md={6} lg={4} key={template.id}>
                  <Card 
                    variant="outlined" 
                    sx={{ 
                      p: 2, 
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      transition: 'all 0.2s',
                      '&:hover': {
                        boxShadow: theme.shadows[4]
                      }
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="h3" noWrap>{template.name}</Typography>
                      <Box>
                        <IconButton 
                          size="small" 
                          onClick={() => handleOpenDialog(template)}
                          sx={{ mr: 1 }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton 
                          size="small" 
                          color="error"
                          onClick={() => handleDeleteClick(template)}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </Box>
                    
                    <Typography 
                      variant="body2" 
                      color="text.secondary"
                      sx={{ 
                        mb: 2,
                        textTransform: 'capitalize',
                        display: 'inline-block',
                        bgcolor: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                        px: 1,
                        py: 0.5,
                        borderRadius: 1
                      }}
                    >
                      {template.type}
                    </Typography>
                    
                    {template.subject && (
                      <Typography variant="body1" sx={{ mb: 1 }}>
                        <strong>Subject:</strong> {template.subject}
                      </Typography>
                    )}
                    
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        flexGrow: 1,
                        overflow: 'hidden',
                        display: '-webkit-box',
                        WebkitLineClamp: 3,
                        WebkitBoxOrient: 'vertical',
                        mb: 2
                      }}
                    >
                      {template.content.replace(/<[^>]*>/g, '')}
                    </Typography>
                    
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => handleOpenDialog(template)}
                      fullWidth
                    >
                      Edit Template
                    </Button>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Card>
      
      {/* Template Dialog */}
      <Dialog 
        open={dialogOpen} 
        onClose={handleCloseDialog}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle>
          {isEditing ? 'Edit Template' : 'Create Template'}
        </DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                name="name"
                label="Template Name"
                value={formData.name}
                onChange={handleInputChange}
                fullWidth
                margin="normal"
                required
              />
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Template Type</InputLabel>
                <Select
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  label="Template Type"
                >
                  {templateTypes.map(type => (
                    <MenuItem key={type.value} value={type.value}>
                      {type.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              {formData.type === 'email' && (
                <TextField
                  name="subject"
                  label="Email Subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  fullWidth
                  margin="normal"
                  required
                />
              )}
              
              <TemplateEditor 
                content={formData.content} 
                onChange={handleContentChange}
                templateType={formData.type}
              />
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                Available variables: {{username}}, {{cardName}}, {{dueDate}}, {{boardName}}, {{cardUrl}}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="h3" sx={{ mb: 2 }}>Preview</Typography>
              <TemplatePreview 
                template={formData}
                variables={{
                  username: 'John Doe',
                  cardName: 'Complete project documentation',
                  dueDate: 'July 15, 2025',
                  boardName: 'Project Alpha',
                  cardUrl: 'https://trello.com/c/abc123'
                }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleSaveTemplate} 
            variant="contained"
            disabled={!formData.name || !formData.content || (formData.type === 'email' && !formData.subject)}
          >
            {isEditing ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        open={confirmDialogOpen}
        title="Delete Template"
        content={`Are you sure you want to delete the template "${currentTemplate?.name}"? This action cannot be undone.`}
        onConfirm={handleConfirmDelete}
        onCancel={() => setConfirmDialogOpen(false)}
      />
    </Box>
  );
};

export default Templates;
