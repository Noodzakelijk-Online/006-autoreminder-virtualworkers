import React, { useState, useContext, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  Grid, 
  TextField, 
  Button, 
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Tabs,
  Tab,
  Divider,
  useTheme
} from '@mui/material';
import { AuthContext } from '../../context/AuthContext';
import AlertBanner from '../../components/common/AlertBanner';
import ColorPicker from '../../components/configuration/ColorPicker';
import WeekdaySelector from '../../components/configuration/WeekdaySelector';
import CronScheduleEditor from '../../components/configuration/CronScheduleEditor';
import TestConnectionButton from '../../components/configuration/TestConnectionButton';

const Configuration = ({ theme, onThemeChange }) => {
  const muiTheme = useTheme();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [config, setConfig] = useState({
    // General settings
    theme: 'dark',
    accentColor: '#8A70FF',
    startMinimized: false,
    startWithSystem: true,
    
    // Reminder settings
    weekendDays: [0, 6], // Sunday, Saturday
    allowUrgentOverride: false,
    reminderTimes: {
      day0: '30 18 * * *', // 6:30 PM for day 0 (same day)
      day1: '0 10 * * *',  // 10:00 AM for day 1 (next day)
      day2: '0 14 * * *'   // 2:00 PM for day 2 (day after next)
    },
    maxReminderDays: 7,
    timezone: 'UTC',
    
    // Notification settings
    enabledChannels: {
      trello: true,
      email: true,
      sms: false,
      whatsapp: false
    },
    
    // Database settings
    databaseMode: 'local',
    cloudUri: '',
    syncInterval: 3600000, // 1 hour in milliseconds
    
    // Report settings
    autoGenerateReports: true,
    reportEmailRecipients: [],
    
    // Log settings
    logRetentionDays: 30
  });
  
  // Email and SMS configuration
  const [emailConfig, setEmailConfig] = useState({
    host: '',
    port: 587,
    secure: false,
    auth: {
      user: '',
      pass: ''
    },
    from: ''
  });
  
  const [twilioConfig, setTwilioConfig] = useState({
    accountSid: '',
    authToken: '',
    phoneNumber: '',
    whatsappNumber: ''
  });

  useEffect(() => {
    fetchConfiguration();
  }, []);

  const fetchConfiguration = async () => {
    try {
      setLoading(true);
      
      // Get general configuration
      const configResponse = await window.api.getConfig();
      
      if (!configResponse.success) {
        throw new Error('Failed to fetch configuration');
      }
      
      // Get email configuration
      const emailResponse = await window.api.getEmailConfig();
      
      if (emailResponse.success) {
        setEmailConfig(emailResponse.config);
      }
      
      // Get Twilio configuration
      const twilioResponse = await window.api.getTwilioConfig();
      
      if (twilioResponse.success) {
        setTwilioConfig(twilioResponse.config);
      }
      
      setConfig(configResponse.config);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching configuration:', error);
      setError(error.message);
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleConfigChange = (e) => {
    const { name, value, checked } = e.target;
    
    // Handle checkbox values
    const newValue = e.target.type === 'checkbox' ? checked : value;
    
    // Handle nested properties
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setConfig({
        ...config,
        [parent]: {
          ...config[parent],
          [child]: newValue
        }
      });
    } else {
      setConfig({
        ...config,
        [name]: newValue
      });
    }
  };

  const handleEmailConfigChange = (e) => {
    const { name, value, checked } = e.target;
    
    // Handle checkbox values
    const newValue = e.target.type === 'checkbox' ? checked : value;
    
    // Handle nested properties
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setEmailConfig({
        ...emailConfig,
        [parent]: {
          ...emailConfig[parent],
          [child]: newValue
        }
      });
    } else {
      setEmailConfig({
        ...emailConfig,
        [name]: newValue
      });
    }
  };

  const handleTwilioConfigChange = (e) => {
    const { name, value } = e.target;
    
    setTwilioConfig({
      ...twilioConfig,
      [name]: value
    });
  };

  const handleWeekendDaysChange = (days) => {
    setConfig({
      ...config,
      weekendDays: days
    });
  };

  const handleReminderTimeChange = (day, cronExpression) => {
    setConfig({
      ...config,
      reminderTimes: {
        ...config.reminderTimes,
        [day]: cronExpression
      }
    });
  };

  const handleThemeColorChange = (newTheme) => {
    setConfig({
      ...config,
      theme: newTheme.mode,
      accentColor: newTheme.accentColor
    });
    
    // Update theme in parent component
    onThemeChange(newTheme);
  };

  const handleSaveConfig = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);
      
      // Save general configuration
      const configResponse = await window.api.updateConfig(config);
      
      if (!configResponse.success) {
        throw new Error('Failed to save configuration');
      }
      
      // Save email configuration if enabled
      if (config.enabledChannels.email) {
        const emailResponse = await window.api.saveEmailConfig(emailConfig);
        
        if (!emailResponse.success) {
          throw new Error('Failed to save email configuration');
        }
      }
      
      // Save Twilio configuration if SMS or WhatsApp is enabled
      if (config.enabledChannels.sms || config.enabledChannels.whatsapp) {
        const twilioResponse = await window.api.saveTwilioConfig(twilioConfig);
        
        if (!twilioResponse.success) {
          throw new Error('Failed to save Twilio configuration');
        }
      }
      
      setSuccess('Configuration saved successfully');
      setSaving(false);
    } catch (error) {
      console.error('Error saving configuration:', error);
      setError(error.message);
      setSaving(false);
    }
  };

  const handleResetConfig = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);
      
      const response = await window.api.resetConfig();
      
      if (!response.success) {
        throw new Error('Failed to reset configuration');
      }
      
      // Update local state
      setConfig(response.config);
      
      // Update theme in parent component
      onThemeChange({
        mode: response.config.theme,
        accentColor: response.config.accentColor
      });
      
      setSuccess('Configuration reset to defaults');
      setSaving(false);
    } catch (error) {
      console.error('Error resetting configuration:', error);
      setError(error.message);
      setSaving(false);
    }
  };

  const handleTestEmailConnection = async () => {
    try {
      setError(null);
      setSuccess(null);
      
      const response = await window.api.testEmailConfig();
      
      if (!response.success) {
        throw new Error('Email connection test failed');
      }
      
      setSuccess('Email connection test successful');
    } catch (error) {
      console.error('Error testing email connection:', error);
      setError(error.message);
    }
  };

  const handleTestTwilioConnection = async () => {
    try {
      setError(null);
      setSuccess(null);
      
      const response = await window.api.testTwilioConfig();
      
      if (!response.success) {
        throw new Error('Twilio connection test failed');
      }
      
      setSuccess('Twilio connection test successful');
    } catch (error) {
      console.error('Error testing Twilio connection:', error);
      setError(error.message);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {error && <AlertBanner severity="error" message={error} sx={{ mb: 3 }} />}
      {success && <AlertBanner severity="success" message={success} sx={{ mb: 3 }} />}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h1">Configuration</Typography>
        <Box>
          <Button 
            variant="outlined" 
            onClick={handleResetConfig}
            sx={{ mr: 2 }}
            disabled={saving}
          >
            Reset to Defaults
          </Button>
          <Button 
            variant="contained" 
            onClick={handleSaveConfig}
            disabled={saving}
          >
            {saving ? <CircularProgress size={24} /> : 'Save Configuration'}
          </Button>
        </Box>
      </Box>
      
      <Card sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="General" />
          <Tab label="Reminders" />
          <Tab label="Notifications" />
          <Tab label="Database" />
          <Tab label="Reports" />
          <Tab label="Logs" />
        </Tabs>
        
        <Box sx={{ p: 3 }}>
          {/* General Settings */}
          {tabValue === 0 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Appearance</Typography>
                
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Theme</InputLabel>
                  <Select
                    name="theme"
                    value={config.theme}
                    onChange={handleConfigChange}
                    label="Theme"
                  >
                    <MenuItem value="light">Light</MenuItem>
                    <MenuItem value="dark">Dark</MenuItem>
                  </Select>
                </FormControl>
                
                <ColorPicker 
                  label="Accent Color"
                  color={config.accentColor}
                  onChange={(color) => handleThemeColorChange({ mode: config.theme, accentColor: color })}
                  sx={{ mb: 3 }}
                />
                
                <Typography variant="h3" sx={{ mb: 2, mt: 3 }}>Startup Options</Typography>
                
                <FormControlLabel
                  control={
                    <Switch
                      name="startMinimized"
                      checked={config.startMinimized}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Start minimized to system tray"
                  sx={{ display: 'block', mb: 2 }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      name="startWithSystem"
                      checked={config.startWithSystem}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Start automatically with Windows"
                  sx={{ display: 'block' }}
                />
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Preview</Typography>
                
                <Card 
                  sx={{ 
                    p: 3, 
                    bgcolor: config.theme === 'dark' ? '#0F1521' : '#FFFFFF',
                    color: config.theme === 'dark' ? '#FFFFFF' : '#1A1F2E',
                    border: `1px solid ${muiTheme.palette.divider}`,
                    height: '100%',
                    minHeight: 300,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center'
                  }}
                >
                  <Typography variant="h2" sx={{ mb: 3 }}>Theme Preview</Typography>
                  
                  <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
                    <Button 
                      variant="contained" 
                      sx={{ bgcolor: config.accentColor }}
                    >
                      Primary Button
                    </Button>
                    
                    <Button variant="outlined">
                      Secondary Button
                    </Button>
                  </Box>
                  
                  <Box 
                    sx={{ 
                      width: '100%', 
                      p: 2, 
                      bgcolor: config.theme === 'dark' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)',
                      borderRadius: 2,
                      mb: 2
                    }}
                  >
                    <Typography variant="body1">
                      This is how your text will appear in the application.
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', gap: 2 }}>
                    <Box 
                      sx={{ 
                        width: 40, 
                        height: 40, 
                        borderRadius: '50%', 
                        bgcolor: config.accentColor,
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        color: '#FFFFFF'
                      }}
                    >
                      A
                    </Box>
                    
                    <Box 
                      sx={{ 
                        width: 40, 
                        height: 40, 
                        borderRadius: '50%', 
                        bgcolor: '#FF9F45',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        color: '#FFFFFF'
                      }}
                    >
                      B
                    </Box>
                    
                    <Box 
                      sx={{ 
                        width: 40, 
                        height: 40, 
                        borderRadius: '50%', 
                        bgcolor: '#4CD964',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        color: '#FFFFFF'
                      }}
                    >
                      C
                    </Box>
                  </Box>
                </Card>
              </Grid>
            </Grid>
          )}
          
          {/* Reminder Settings */}
          {tabValue === 1 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Weekend Configuration</Typography>
                
                <WeekdaySelector 
                  selectedDays={config.weekendDays}
                  onChange={handleWeekendDaysChange}
                  sx={{ mb: 3 }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      name="allowUrgentOverride"
                      checked={config.allowUrgentOverride}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Allow urgent reminders on weekends"
                  sx={{ display: 'block', mb: 3 }}
                />
                
                <Typography variant="h3" sx={{ mb: 2, mt: 3 }}>Reminder Schedule</Typography>
                
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Timezone</InputLabel>
                  <Select
                    name="timezone"
                    value={config.timezone}
                    onChange={handleConfigChange}
                    label="Timezone"
                  >
                    <MenuItem value="UTC">UTC</MenuItem>
                    <MenuItem value="America/New_York">Eastern Time (ET)</MenuItem>
                    <MenuItem value="America/Chicago">Central Time (CT)</MenuItem>
                    <MenuItem value="America/Denver">Mountain Time (MT)</MenuItem>
                    <MenuItem value="America/Los_Angeles">Pacific Time (PT)</MenuItem>
                    <MenuItem value="Europe/London">London (GMT)</MenuItem>
                    <MenuItem value="Europe/Paris">Paris (CET)</MenuItem>
                    <MenuItem value="Asia/Tokyo">Tokyo (JST)</MenuItem>
                  </Select>
                </FormControl>
                
                <TextField
                  name="maxReminderDays"
                  label="Maximum Days to Send Reminders"
                  type="number"
                  value={config.maxReminderDays}
                  onChange={handleConfigChange}
                  fullWidth
                  margin="normal"
                  InputProps={{ inputProps: { min: 1, max: 30 } }}
                  helperText="Maximum number of days before due date to send reminders"
                />
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Reminder Times</Typography>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  Configure when reminders should be sent using cron expressions.
                </Typography>
                
                <CronScheduleEditor
                  label="Same Day (Day 0)"
                  value={config.reminderTimes.day0}
                  onChange={(value) => handleReminderTimeChange('day0', value)}
                  sx={{ mb: 2 }}
                />
                
                <CronScheduleEditor
                  label="Next Day (Day 1)"
                  value={config.reminderTimes.day1}
                  onChange={(value) => handleReminderTimeChange('day1', value)}
                  sx={{ mb: 2 }}
                />
                
                <CronScheduleEditor
                  label="Day After Next (Day 2)"
                  value={config.reminderTimes.day2}
                  onChange={(value) => handleReminderTimeChange('day2', value)}
                  sx={{ mb: 2 }}
                />
                
                <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                  Cron format: minute hour * * * (e.g., "0 10 * * *" for 10:00 AM daily)
                </Typography>
              </Grid>
            </Grid>
          )}
          
          {/* Notification Settings */}
          {tabValue === 2 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Notification Channels</Typography>
                
                <FormControlLabel
                  control={
                    <Switch
                      name="enabledChannels.trello"
                      checked={config.enabledChannels.trello}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Trello Comments"
                  sx={{ display: 'block', mb: 2 }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      name="enabledChannels.email"
                      checked={config.enabledChannels.email}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Email Notifications"
                  sx={{ display: 'block', mb: 2 }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      name="enabledChannels.sms"
                      checked={config.enabledChannels.sms}
                      onChange={handleConfigChange}
                    />
                  }
                  label="SMS Notifications"
                  sx={{ display: 'block', mb: 2 }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      name="enabledChannels.whatsapp"
                      checked={config.enabledChannels.whatsapp}
                      onChange={handleConfigChange}
                    />
                  }
                  label="WhatsApp Notifications"
                  sx={{ display: 'block', mb: 3 }}
                />
                
                <Divider sx={{ my: 3 }} />
                
                {config.enabledChannels.email && (
                  <>
                    <Typography variant="h3" sx={{ mb: 2 }}>Email Configuration</Typography>
                    
                    <TextField
                      name="host"
                      label="SMTP Host"
                      value={emailConfig.host}
                      onChange={handleEmailConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <TextField
                      name="port"
                      label="SMTP Port"
                      type="number"
                      value={emailConfig.port}
                      onChange={handleEmailConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <FormControlLabel
                      control={
                        <Switch
                          name="secure"
                          checked={emailConfig.secure}
                          onChange={handleEmailConfigChange}
                        />
                      }
                      label="Use SSL/TLS"
                      sx={{ display: 'block', my: 2 }}
                    />
                    
                    <TextField
                      name="auth.user"
                      label="SMTP Username"
                      value={emailConfig.auth.user}
                      onChange={handleEmailConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <TextField
                      name="auth.pass"
                      label="SMTP Password"
                      type="password"
                      value={emailConfig.auth.pass}
                      onChange={handleEmailConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <TextField
                      name="from"
                      label="From Email Address"
                      value={emailConfig.from}
                      onChange={handleEmailConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <TestConnectionButton
                      label="Test Email Connection"
                      onClick={handleTestEmailConnection}
                      sx={{ mt: 2 }}
                    />
                    
                    <Divider sx={{ my: 3 }} />
                  </>
                )}
              </Grid>
              
              <Grid item xs={12} md={6}>
                {(config.enabledChannels.sms || config.enabledChannels.whatsapp) && (
                  <>
                    <Typography variant="h3" sx={{ mb: 2 }}>Twilio Configuration</Typography>
                    
                    <TextField
                      name="accountSid"
                      label="Account SID"
                      value={twilioConfig.accountSid}
                      onChange={handleTwilioConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <TextField
                      name="authToken"
                      label="Auth Token"
                      type="password"
                      value={twilioConfig.authToken}
                      onChange={handleTwilioConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    {config.enabledChannels.sms && (
                      <TextField
                        name="phoneNumber"
                        label="Twilio Phone Number"
                        value={twilioConfig.phoneNumber}
                        onChange={handleTwilioConfigChange}
                        fullWidth
                        margin="normal"
                        required
                        helperText="Format: +1234567890"
                      />
                    )}
                    
                    {config.enabledChannels.whatsapp && (
                      <TextField
                        name="whatsappNumber"
                        label="Twilio WhatsApp Number"
                        value={twilioConfig.whatsappNumber}
                        onChange={handleTwilioConfigChange}
                        fullWidth
                        margin="normal"
                        required
                        helperText="Format: +1234567890"
                      />
                    )}
                    
                    <TestConnectionButton
                      label="Test Twilio Connection"
                      onClick={handleTestTwilioConnection}
                      sx={{ mt: 2 }}
                    />
                  </>
                )}
              </Grid>
            </Grid>
          )}
          
          {/* Database Settings */}
          {tabValue === 3 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Database Mode</Typography>
                
                <FormControl fullWidth sx={{ mb: 3 }}>
                  <InputLabel>Database Mode</InputLabel>
                  <Select
                    name="databaseMode"
                    value={config.databaseMode}
                    onChange={handleConfigChange}
                    label="Database Mode"
                  >
                    <MenuItem value="local">Local Only</MenuItem>
                    <MenuItem value="cloud">Cloud Only</MenuItem>
                    <MenuItem value="hybrid">Hybrid (Local + Cloud Sync)</MenuItem>
                  </Select>
                </FormControl>
                
                {(config.databaseMode === 'cloud' || config.databaseMode === 'hybrid') && (
                  <>
                    <TextField
                      name="cloudUri"
                      label="Cloud Database URI"
                      value={config.cloudUri}
                      onChange={handleConfigChange}
                      fullWidth
                      margin="normal"
                      required
                    />
                    
                    <Typography variant="h3" sx={{ mb: 2, mt: 3 }}>Sync Settings</Typography>
                    
                    <FormControl fullWidth sx={{ mb: 2 }}>
                      <InputLabel>Sync Interval</InputLabel>
                      <Select
                        name="syncInterval"
                        value={config.syncInterval}
                        onChange={handleConfigChange}
                        label="Sync Interval"
                      >
                        <MenuItem value={300000}>5 minutes</MenuItem>
                        <MenuItem value={900000}>15 minutes</MenuItem>
                        <MenuItem value={1800000}>30 minutes</MenuItem>
                        <MenuItem value={3600000}>1 hour</MenuItem>
                        <MenuItem value={7200000}>2 hours</MenuItem>
                        <MenuItem value={14400000}>4 hours</MenuItem>
                        <MenuItem value={28800000}>8 hours</MenuItem>
                        <MenuItem value={86400000}>24 hours</MenuItem>
                      </Select>
                    </FormControl>
                    
                    <Button 
                      variant="outlined" 
                      onClick={() => window.api.syncDatabase()}
                      sx={{ mt: 1 }}
                    >
                      Sync Now
                    </Button>
                  </>
                )}
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Database Information</Typography>
                
                <Card variant="outlined" sx={{ p: 2, mb: 3 }}>
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    <strong>Mode:</strong> {config.databaseMode === 'local' ? 'Local Only' : config.databaseMode === 'cloud' ? 'Cloud Only' : 'Hybrid'}
                  </Typography>
                  
                  {(config.databaseMode === 'cloud' || config.databaseMode === 'hybrid') && (
                    <Typography variant="body1" sx={{ mb: 1 }}>
                      <strong>Cloud URI:</strong> {config.cloudUri || 'Not configured'}
                    </Typography>
                  )}
                  
                  <Typography variant="body1" sx={{ mb: 1 }}>
                    <strong>Sync Interval:</strong> {config.syncInterval / 60000} minutes
                  </Typography>
                  
                  <Typography variant="body1">
                    <strong>Last Sync:</strong> {config.lastSyncTime ? new Date(config.lastSyncTime).toLocaleString() : 'Never'}
                  </Typography>
                </Card>
                
                <Typography variant="body2" color="text.secondary">
                  <strong>Note:</strong> Changing database mode may require restarting the application.
                  Make sure to save any unsaved data before changing modes.
                </Typography>
              </Grid>
            </Grid>
          )}
          
          {/* Report Settings */}
          {tabValue === 4 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Report Generation</Typography>
                
                <FormControlLabel
                  control={
                    <Switch
                      name="autoGenerateReports"
                      checked={config.autoGenerateReports}
                      onChange={handleConfigChange}
                    />
                  }
                  label="Automatically generate weekly reports"
                  sx={{ display: 'block', mb: 3 }}
                />
                
                <Typography variant="h3" sx={{ mb: 2, mt: 3 }}>Report Delivery</Typography>
                
                <TextField
                  name="reportEmailRecipients"
                  label="Email Recipients"
                  value={Array.isArray(config.reportEmailRecipients) ? config.reportEmailRecipients.join(', ') : ''}
                  onChange={(e) => {
                    const recipients = e.target.value.split(',').map(email => email.trim()).filter(email => email);
                    setConfig({
                      ...config,
                      reportEmailRecipients: recipients
                    });
                  }}
                  fullWidth
                  margin="normal"
                  helperText="Comma-separated list of email addresses"
                />
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Report Types</Typography>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  The following report types are available:
                </Typography>
                
                <Card variant="outlined" sx={{ p: 2, mb: 2 }}>
                  <Typography variant="h4" sx={{ mb: 1 }}>Weekly Summary</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Provides a summary of all activity for the past week, including cards due,
                    notifications sent, and response rates.
                  </Typography>
                </Card>
                
                <Card variant="outlined" sx={{ p: 2, mb: 2 }}>
                  <Typography variant="h4" sx={{ mb: 1 }}>Monthly Summary</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Provides a summary of all activity for the past month, with detailed metrics
                    and trends over time.
                  </Typography>
                </Card>
                
                <Card variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="h4" sx={{ mb: 1 }}>Custom Period</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Generate a report for a custom date range, with all metrics and statistics.
                  </Typography>
                </Card>
              </Grid>
            </Grid>
          )}
          
          {/* Log Settings */}
          {tabValue === 5 && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Log Retention</Typography>
                
                <TextField
                  name="logRetentionDays"
                  label="Log Retention Period (Days)"
                  type="number"
                  value={config.logRetentionDays}
                  onChange={handleConfigChange}
                  fullWidth
                  margin="normal"
                  InputProps={{ inputProps: { min: 1, max: 365 } }}
                  helperText="Logs older than this will be automatically deleted"
                />
                
                <Button 
                  variant="outlined" 
                  onClick={() => window.api.clearOldLogs(config.logRetentionDays)}
                  sx={{ mt: 2 }}
                >
                  Clear Old Logs Now
                </Button>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="h3" sx={{ mb: 2 }}>Log Information</Typography>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Logs are stored locally and include:
                </Typography>
                
                <ul>
                  <li>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      Notification delivery status
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      Trello API interactions
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      System errors and warnings
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      User actions and configuration changes
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2">
                      Database synchronization events
                    </Typography>
                  </li>
                </ul>
                
                <Typography variant="body2" color="text.secondary" sx={{ mt: 3 }}>
                  You can view detailed logs in the Logs section of the application.
                </Typography>
              </Grid>
            </Grid>
          )}
        </Box>
      </Card>
    </Box>
  );
};

export default Configuration;
