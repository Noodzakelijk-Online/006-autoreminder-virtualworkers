const log = require('electron-log');
const { v4: uuidv4 } = require('uuid');
const { getLocalDatabase } = require('./database');

/**
 * Default configuration values
 */
const DEFAULT_CONFIG = {
  // Weekend configuration
  weekendDays: [0, 6], // Sunday, Saturday
  allowUrgentOverride: false,
  
  // Reminder times (cron expressions)
  reminderTimes: {
    day0: '30 18 * * *', // 6:30 PM for day 0 (same day)
    day1: '0 10 * * *',  // 10:00 AM for day 1 (next day)
    day2: '0 14 * * *'   // 2:00 PM for day 2 (day after next)
  },
  
  // Maximum days to send reminders
  maxReminderDays: 7,
  
  // Timezone
  timezone: 'UTC',
  
  // Notification channels
  enabledChannels: {
    trello: true,
    email: true,
    sms: false,
    whatsapp: false
  },
  
  // Sync settings
  syncInterval: 3600000, // 1 hour in milliseconds
  
  // Report settings
  autoGenerateReports: true,
  reportEmailRecipients: [],
  
  // UI settings
  theme: 'dark',
  accentColor: '#8A70FF',
  
  // Startup settings
  startMinimized: false,
  startWithSystem: true,
  
  // Log settings
  logRetentionDays: 30
};

/**
 * Get configuration
 * @returns {Object} Configuration
 */
const getConfig = () => {
  try {
    const db = getLocalDatabase();
    
    // Get all configuration entries
    const configEntries = db.prepare('SELECT key, value FROM configuration').all();
    
    // Convert to object
    const config = { ...DEFAULT_CONFIG };
    
    configEntries.forEach(entry => {
      try {
        // Parse JSON values
        const value = JSON.parse(entry.value);
        
        // Handle nested properties
        if (entry.key.includes('.')) {
          const parts = entry.key.split('.');
          if (!config[parts[0]]) {
            config[parts[0]] = {};
          }
          config[parts[0]][parts[1]] = value;
        } else {
          config[entry.key] = value;
        }
      } catch (e) {
        // If not valid JSON, use as is
        if (entry.key.includes('.')) {
          const parts = entry.key.split('.');
          if (!config[parts[0]]) {
            config[parts[0]] = {};
          }
          config[parts[0]][parts[1]] = entry.value;
        } else {
          config[entry.key] = entry.value;
        }
      }
    });
    
    return config;
  } catch (error) {
    log.error('Error getting configuration:', error);
    return DEFAULT_CONFIG;
  }
};

/**
 * Update configuration
 * @param {Object} configData - Configuration data
 * @returns {Object} Updated configuration
 */
const updateConfig = (configData) => {
  try {
    const db = getLocalDatabase();
    
    const now = Date.now();
    
    // Flatten object for storage
    const flattenedConfig = flattenObject(configData);
    
    // Update each configuration entry
    Object.entries(flattenedConfig).forEach(([key, value]) => {
      // Convert objects and arrays to JSON strings
      const storedValue = typeof value === 'object' ? JSON.stringify(value) : value;
      
      // Check if entry exists
      const existing = db.prepare('SELECT id FROM configuration WHERE key = ?').get(key);
      
      if (existing) {
        // Update existing entry
        db.prepare(`
          UPDATE configuration
          SET value = ?, updated_at = ?
          WHERE key = ?
        `).run(storedValue, now, key);
      } else {
        // Create new entry
        const id = uuidv4();
        
        db.prepare(`
          INSERT INTO configuration (id, key, value, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?)
        `).run(id, key, storedValue, now, now);
      }
    });
    
    // Log configuration update
    log.info('Configuration updated');
    
    return getConfig();
  } catch (error) {
    log.error('Error updating configuration:', error);
    throw error;
  }
};

/**
 * Reset configuration to defaults
 * @returns {Object} Default configuration
 */
const resetConfig = () => {
  try {
    const db = getLocalDatabase();
    
    // Delete all configuration entries
    db.prepare('DELETE FROM configuration').run();
    
    // Insert default configuration
    updateConfig(DEFAULT_CONFIG);
    
    // Log configuration reset
    log.info('Configuration reset to defaults');
    
    return DEFAULT_CONFIG;
  } catch (error) {
    log.error('Error resetting configuration:', error);
    throw error;
  }
};

/**
 * Initialize configuration
 */
const initConfig = () => {
  try {
    const db = getLocalDatabase();
    
    // Check if configuration exists
    const count = db.prepare('SELECT COUNT(*) as count FROM configuration').get().count;
    
    if (count === 0) {
      // Insert default configuration
      updateConfig(DEFAULT_CONFIG);
      
      log.info('Default configuration initialized');
    }
  } catch (error) {
    log.error('Error initializing configuration:', error);
  }
};

/**
 * Flatten object (for storage)
 * @param {Object} obj - Object to flatten
 * @param {string} prefix - Key prefix
 * @returns {Object} Flattened object
 */
const flattenObject = (obj, prefix = '') => {
  return Object.keys(obj).reduce((acc, key) => {
    const prefixedKey = prefix ? `${prefix}.${key}` : key;
    
    if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
      Object.assign(acc, flattenObject(obj[key], prefixedKey));
    } else {
      acc[prefixedKey] = obj[key];
    }
    
    return acc;
  }, {});
};

module.exports = {
  DEFAULT_CONFIG,
  getConfig,
  updateConfig,
  resetConfig,
  initConfig
};
