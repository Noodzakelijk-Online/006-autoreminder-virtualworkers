const log = require('electron-log');
const { v4: uuidv4 } = require('uuid');
const { getLocalDatabase } = require('./database');
const { getTemplate, applyTemplate } = require('./templates');
const trelloService = require('./trello');
const emailService = require('./email');
const smsService = require('./sms');
const moment = require('moment');

/**
 * Send notification through multiple channels
 * @param {string} cardId - Card ID
 * @param {Array<string>} channels - Notification channels (email, sms, whatsapp, trello)
 * @param {string} message - Custom message (optional)
 * @returns {Promise<Object>} Notification results
 */
const sendNotification = async (cardId, channels, message = null) => {
  try {
    const db = getLocalDatabase();
    
    // Get card data
    const card = db.prepare('SELECT * FROM cards WHERE id = ?').get(cardId);
    
    if (!card) {
      throw new Error(`Card not found: ${cardId}`);
    }
    
    // Parse card members
    const members = JSON.parse(card.members || '[]');
    
    // Results object
    const results = {
      success: true,
      sent: [],
      failed: []
    };
    
    // Process each channel
    for (const channel of channels) {
      try {
        switch (channel) {
          case 'email':
            await sendEmailNotification(card, members, message);
            results.sent.push('email');
            break;
            
          case 'sms':
            await sendSmsNotification(card, members, message);
            results.sent.push('sms');
            break;
            
          case 'whatsapp':
            await sendWhatsAppNotification(card, members, message);
            results.sent.push('whatsapp');
            break;
            
          case 'trello':
            await sendTrelloNotification(card, members, message);
            results.sent.push('trello');
            break;
            
          default:
            log.warn(`Unknown notification channel: ${channel}`);
            results.failed.push(channel);
        }
      } catch (error) {
        log.error(`Error sending ${channel} notification:`, error);
        results.failed.push(channel);
        results.success = false;
      }
    }
    
    return results;
  } catch (error) {
    log.error('Error sending notification:', error);
    throw error;
  }
};

/**
 * Send email notification
 * @param {Object} card - Card data
 * @param {Array} members - Card members
 * @param {string} customMessage - Custom message (optional)
 * @returns {Promise<Array>} Email results
 */
const sendEmailNotification = async (card, members, customMessage = null) => {
  try {
    const db = getLocalDatabase();
    
    // Get email template
    const emailTemplate = db.prepare('SELECT * FROM templates WHERE type = ? LIMIT 1').get('email');
    
    if (!emailTemplate && !customMessage) {
      throw new Error('Email template not found');
    }
    
    const results = [];
    
    // Send email to each member
    for (const member of members) {
      if (!member.email) {
        log.warn(`Member ${member.fullName} has no email address`);
        continue;
      }
      
      // Prepare variables
      const variables = {
        username: member.fullName,
        cardName: card.name,
        cardUrl: card.url,
        dueDate: moment(card.due_date).format('MMMM Do, YYYY [at] h:mm a'),
        boardName: card.board_name
      };
      
      // Use custom message or template
      let subject, text, html;
      
      if (customMessage) {
        subject = `Notification: ${card.name}`;
        text = customMessage;
        html = `<p>${customMessage}</p>`;
      } else {
        // Apply template
        const processedTemplate = applyTemplate(emailTemplate, variables);
        subject = processedTemplate.subject;
        html = processedTemplate.content;
        text = html.replace(/<[^>]*>/g, ''); // Strip HTML tags for plain text
      }
      
      // Send email
      const result = await emailService.sendEmail(member.email, subject, text, html);
      
      // Log notification
      logNotification({
        card_id: card.id,
        template_id: customMessage ? null : emailTemplate.id,
        channel: 'email',
        recipient: member.email,
        message: customMessage || emailTemplate.content,
        status: 'success',
        sent_at: Date.now()
      });
      
      results.push(result);
    }
    
    return results;
  } catch (error) {
    log.error('Error sending email notification:', error);
    
    // Log notification failure
    logNotification({
      card_id: card.id,
      template_id: null,
      channel: 'email',
      recipient: 'multiple',
      message: error.message,
      status: 'error',
      sent_at: null
    });
    
    throw error;
  }
};

/**
 * Send SMS notification
 * @param {Object} card - Card data
 * @param {Array} members - Card members
 * @param {string} customMessage - Custom message (optional)
 * @returns {Promise<Array>} SMS results
 */
const sendSmsNotification = async (card, members, customMessage = null) => {
  try {
    const db = getLocalDatabase();
    
    // Get SMS template
    const smsTemplate = db.prepare('SELECT * FROM templates WHERE type = ? LIMIT 1').get('sms');
    
    if (!smsTemplate && !customMessage) {
      throw new Error('SMS template not found');
    }
    
    const results = [];
    
    // Send SMS to each member
    for (const member of members) {
      if (!member.phone) {
        log.warn(`Member ${member.fullName} has no phone number`);
        continue;
      }
      
      // Prepare variables
      const variables = {
        username: member.fullName,
        cardName: card.name,
        dueDate: moment(card.due_date).format('MMM Do, YYYY'),
        boardName: card.board_name
      };
      
      // Use custom message or template
      let message;
      
      if (customMessage) {
        message = customMessage;
      } else {
        // Apply template
        const processedTemplate = applyTemplate(smsTemplate, variables);
        message = processedTemplate.content;
      }
      
      // Send SMS
      const result = await smsService.sendSMS(member.phone, message);
      
      // Log notification
      logNotification({
        card_id: card.id,
        template_id: customMessage ? null : smsTemplate.id,
        channel: 'sms',
        recipient: member.phone,
        message,
        status: 'success',
        sent_at: Date.now()
      });
      
      results.push(result);
    }
    
    return results;
  } catch (error) {
    log.error('Error sending SMS notification:', error);
    
    // Log notification failure
    logNotification({
      card_id: card.id,
      template_id: null,
      channel: 'sms',
      recipient: 'multiple',
      message: error.message,
      status: 'error',
      sent_at: null
    });
    
    throw error;
  }
};

/**
 * Send WhatsApp notification
 * @param {Object} card - Card data
 * @param {Array} members - Card members
 * @param {string} customMessage - Custom message (optional)
 * @returns {Promise<Array>} WhatsApp results
 */
const sendWhatsAppNotification = async (card, members, customMessage = null) => {
  try {
    const db = getLocalDatabase();
    
    // Get WhatsApp template
    const whatsappTemplate = db.prepare('SELECT * FROM templates WHERE type = ? LIMIT 1').get('whatsapp');
    
    if (!whatsappTemplate && !customMessage) {
      throw new Error('WhatsApp template not found');
    }
    
    const results = [];
    
    // Send WhatsApp to each member
    for (const member of members) {
      if (!member.phone) {
        log.warn(`Member ${member.fullName} has no phone number`);
        continue;
      }
      
      // Prepare variables
      const variables = {
        username: member.fullName,
        cardName: card.name,
        dueDate: moment(card.due_date).format('MMM Do, YYYY'),
        boardName: card.board_name
      };
      
      // Use custom message or template
      let message;
      
      if (customMessage) {
        message = customMessage;
      } else {
        // Apply template
        const processedTemplate = applyTemplate(whatsappTemplate, variables);
        message = processedTemplate.content;
      }
      
      // Send WhatsApp
      const result = await smsService.sendWhatsApp(member.phone, message);
      
      // Log notification
      logNotification({
        card_id: card.id,
        template_id: customMessage ? null : whatsappTemplate.id,
        channel: 'whatsapp',
        recipient: member.phone,
        message,
        status: 'success',
        sent_at: Date.now()
      });
      
      results.push(result);
    }
    
    return results;
  } catch (error) {
    log.error('Error sending WhatsApp notification:', error);
    
    // Log notification failure
    logNotification({
      card_id: card.id,
      template_id: null,
      channel: 'whatsapp',
      recipient: 'multiple',
      message: error.message,
      status: 'error',
      sent_at: null
    });
    
    throw error;
  }
};

/**
 * Send Trello notification
 * @param {Object} card - Card data
 * @param {Array} members - Card members
 * @param {string} customMessage - Custom message (optional)
 * @returns {Promise<Object>} Trello comment result
 */
const sendTrelloNotification = async (card, members, customMessage = null) => {
  try {
    const db = getLocalDatabase();
    
    // Get Trello template
    const trelloTemplate = db.prepare('SELECT * FROM templates WHERE type = ? LIMIT 1').get('trello');
    
    if (!trelloTemplate && !customMessage) {
      throw new Error('Trello template not found');
    }
    
    // Prepare variables
    const variables = {
      username: members.map(m => m.username).join(' @'),
      cardName: card.name,
      dueDate: moment(card.due_date).format('MMM Do, YYYY'),
      boardName: card.board_name
    };
    
    // Use custom message or template
    let message;
    
    if (customMessage) {
      message = customMessage;
    } else {
      // Apply template
      const processedTemplate = applyTemplate(trelloTemplate, variables);
      message = processedTemplate.content;
    }
    
    // Post comment
    const result = await trelloService.postComment(card.id, message);
    
    // Log notification
    logNotification({
      card_id: card.id,
      template_id: customMessage ? null : trelloTemplate.id,
      channel: 'trello',
      recipient: card.id,
      message,
      status: 'success',
      sent_at: Date.now()
    });
    
    return result;
  } catch (error) {
    log.error('Error sending Trello notification:', error);
    
    // Log notification failure
    logNotification({
      card_id: card.id,
      template_id: null,
      channel: 'trello',
      recipient: card.id,
      message: error.message,
      status: 'error',
      sent_at: null
    });
    
    throw error;
  }
};

/**
 * Log notification
 * @param {Object} notificationData - Notification data
 */
const logNotification = (notificationData) => {
  try {
    const db = getLocalDatabase();
    
    const now = Date.now();
    const id = uuidv4();
    
    const notification = {
      id,
      card_id: notificationData.card_id,
      template_id: notificationData.template_id,
      channel: notificationData.channel,
      recipient: notificationData.recipient,
      message: notificationData.message,
      status: notificationData.status,
      sent_at: notificationData.sent_at,
      created_at: now,
      updated_at: now
    };
    
    db.prepare(`
      INSERT INTO notifications (
        id, card_id, template_id, channel, recipient, message, 
        status, sent_at, created_at, updated_at
      )
      VALUES (
        @id, @card_id, @template_id, @channel, @recipient, @message, 
        @status, @sent_at, @created_at, @updated_at
      )
    `).run(notification);
    
    // Also add to logs table
    const logEntry = {
      id: uuidv4(),
      timestamp: now,
      type: 'notification',
      channel: notificationData.channel,
      message: `Notification ${notificationData.status}: ${notificationData.channel} to ${notificationData.recipient}`,
      status: notificationData.status,
      card_id: notificationData.card_id,
      created_at: now
    };
    
    db.prepare(`
      INSERT INTO logs (
        id, timestamp, type, channel, message, status, card_id, created_at
      )
      VALUES (
        @id, @timestamp, @type, @channel, @message, @status, @card_id, @created_at
      )
    `).run(logEntry);
    
  } catch (error) {
    log.error('Error logging notification:', error);
  }
};

/**
 * Get notification status
 * @returns {Object} Notification statistics
 */
const getNotificationStatus = () => {
  try {
    const db = getLocalDatabase();
    
    // Get total cards
    const totalCards = db.prepare('SELECT COUNT(*) as count FROM cards').get().count;
    
    // Get cards with reminders
    const cardsWithReminders = db.prepare(`
      SELECT COUNT(DISTINCT card_id) as count FROM reminders
    `).get().count;
    
    // Get cards with responses (implementation depends on how responses are tracked)
    const cardsWithResponses = 0; // Placeholder
    
    // Get response rate
    const responseRate = totalCards > 0 ? cardsWithResponses / totalCards : 0;
    
    // Get reminder counts by day
    const reminderCounts = db.prepare(`
      SELECT day_offset as _id, COUNT(*) as count 
      FROM reminders 
      GROUP BY day_offset
      ORDER BY day_offset
    `).all();
    
    // Get notification counts by channel
    const notificationsByChannel = db.prepare(`
      SELECT channel, COUNT(*) as count 
      FROM notifications 
      WHERE status = 'success'
      GROUP BY channel
    `).all();
    
    // Format notification counts
    const notificationsSent = {};
    notificationsByChannel.forEach(item => {
      notificationsSent[item.channel] = item.count;
    });
    
    return {
      totalCards,
      cardsWithReminders,
      cardsWithResponses,
      responseRate,
      reminderCounts,
      metrics: {
        notificationsSent
      }
    };
  } catch (error) {
    log.error('Error getting notification status:', error);
    throw error;
  }
};

module.exports = {
  sendNotification,
  getNotificationStatus
};
