const cron = require('node-cron');
const moment = require('moment');
const log = require('electron-log');
const Store = require('electron-store');

// Initialize store for scheduler configuration
const store = new Store();

// Map of scheduled jobs
const scheduledJobs = new Map();

/**
 * Get scheduler configuration from store
 * @returns {Object} Scheduler configuration
 */
const getSchedulerConfig = () => {
  return {
    timezone: store.get('scheduler.timezone') || 'UTC',
    weekendDays: store.get('scheduler.weekendDays') || [0, 6], // Sunday, Saturday
    reminderTimes: store.get('scheduler.reminderTimes') || {
      day0: '30 18 * * *', // 6:30 PM for day 0 (same day)
      day1: '0 10 * * *',  // 10:00 AM for day 1 (next day)
      day2: '0 14 * * *'   // 2:00 PM for day 2 (day after next)
    },
    maxReminderDays: store.get('scheduler.maxReminderDays') || 7,
    allowUrgentOverride: store.get('scheduler.allowUrgentOverride') || false
  };
};

/**
 * Save scheduler configuration
 * @param {Object} config - Scheduler configuration
 * @returns {boolean} Save result
 */
const saveSchedulerConfig = (config) => {
  try {
    store.set('scheduler.timezone', config.timezone);
    store.set('scheduler.weekendDays', config.weekendDays);
    store.set('scheduler.reminderTimes', config.reminderTimes);
    store.set('scheduler.maxReminderDays', config.maxReminderDays);
    store.set('scheduler.allowUrgentOverride', config.allowUrgentOverride);
    
    // Reschedule jobs with new configuration
    rescheduleAllJobs();
    
    return true;
  } catch (error) {
    log.error('Error saving scheduler configuration:', error);
    return false;
  }
};

/**
 * Check if a date is a weekend
 * @param {Date} date - Date to check
 * @returns {boolean} True if weekend
 */
const isWeekend = (date) => {
  const config = getSchedulerConfig();
  const day = date.getDay();
  return config.weekendDays.includes(day);
};

/**
 * Schedule a reminder job
 * @param {string} jobId - Unique job ID
 * @param {string} cronExpression - Cron expression
 * @param {Function} callback - Callback function
 * @returns {Object} Scheduled job
 */
const scheduleJob = (jobId, cronExpression, callback) => {
  try {
    // Cancel existing job with same ID
    if (scheduledJobs.has(jobId)) {
      scheduledJobs.get(jobId).stop();
      scheduledJobs.delete(jobId);
    }
    
    const config = getSchedulerConfig();
    
    // Schedule new job
    const job = cron.schedule(cronExpression, callback, {
      timezone: config.timezone,
      scheduled: true
    });
    
    // Store job
    scheduledJobs.set(jobId, job);
    
    log.info(`Scheduled job ${jobId}: ${cronExpression}`);
    
    return job;
  } catch (error) {
    log.error(`Error scheduling job ${jobId}:`, error);
    throw error;
  }
};

/**
 * Cancel a scheduled job
 * @param {string} jobId - Job ID
 * @returns {boolean} True if job was cancelled
 */
const cancelJob = (jobId) => {
  if (scheduledJobs.has(jobId)) {
    scheduledJobs.get(jobId).stop();
    scheduledJobs.delete(jobId);
    log.info(`Cancelled job ${jobId}`);
    return true;
  }
  
  return false;
};

/**
 * Reschedule all jobs
 */
const rescheduleAllJobs = () => {
  // Implementation depends on how jobs are stored and managed
  // This would typically involve fetching all scheduled reminders from the database
  // and rescheduling them with the new configuration
  log.info('Rescheduling all jobs with new configuration');
};

/**
 * Schedule reminder for a card
 * @param {Object} card - Card data
 * @param {Function} notificationCallback - Callback for sending notification
 * @returns {Array<string>} Scheduled job IDs
 */
const scheduleCardReminders = (card, notificationCallback) => {
  try {
    const config = getSchedulerConfig();
    const jobIds = [];
    
    // Only schedule reminders for cards with due dates
    if (!card.due) {
      return jobIds;
    }
    
    const dueDate = new Date(card.due);
    
    // Schedule reminders based on configuration
    Object.entries(config.reminderTimes).forEach(([dayKey, cronExpression]) => {
      const dayOffset = parseInt(dayKey.replace('day', ''), 10);
      
      // Calculate reminder date
      const reminderDate = new Date(dueDate);
      reminderDate.setDate(reminderDate.getDate() - dayOffset);
      
      // Skip weekends unless urgent override is enabled
      if (isWeekend(reminderDate) && !config.allowUrgentOverride && !card.isUrgent) {
        return;
      }
      
      // Skip if reminder date is in the past
      if (reminderDate < new Date()) {
        return;
      }
      
      // Skip if reminder date is too far in the future
      const maxDaysInFuture = moment(dueDate).diff(moment(), 'days');
      if (maxDaysInFuture > config.maxReminderDays) {
        return;
      }
      
      // Create job ID
      const jobId = `reminder_${card.id}_${dayKey}`;
      
      // Schedule job
      scheduleJob(jobId, cronExpression, () => {
        notificationCallback(card, dayOffset);
      });
      
      jobIds.push(jobId);
    });
    
    return jobIds;
  } catch (error) {
    log.error('Error scheduling card reminders:', error);
    throw error;
  }
};

/**
 * Schedule daily sync job
 * @param {Function} syncCallback - Callback for syncing
 * @returns {string} Job ID
 */
const scheduleDailySync = (syncCallback) => {
  const jobId = 'daily_sync';
  
  // Schedule job to run at 1:00 AM every day
  scheduleJob(jobId, '0 1 * * *', syncCallback);
  
  return jobId;
};

/**
 * Schedule weekly report job
 * @param {Function} reportCallback - Callback for generating report
 * @returns {string} Job ID
 */
const scheduleWeeklyReport = (reportCallback) => {
  const jobId = 'weekly_report';
  
  // Schedule job to run at 2:00 AM every Monday
  scheduleJob(jobId, '0 2 * * 1', reportCallback);
  
  return jobId;
};

module.exports = {
  getSchedulerConfig,
  saveSchedulerConfig,
  scheduleJob,
  cancelJob,
  scheduleCardReminders,
  scheduleDailySync,
  scheduleWeeklyReport,
  isWeekend
};
