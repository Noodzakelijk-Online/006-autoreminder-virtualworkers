const axios = require('axios');
const log = require('electron-log');
const Store = require('electron-store');
const { BrowserWindow } = require('electron');

// Initialize store for Trello credentials
const store = new Store();

// Trello API base URL
const TRELLO_API_BASE_URL = 'https://api.trello.com/1';

// Trello API key and token from store
const getTrelloCredentials = () => {
  const apiKey = store.get('trello.apiKey');
  const token = store.get('trello.token');
  return { apiKey, token };
};

// Trello authentication window
let authWindow = null;

/**
 * Authenticate with Trello using OAuth
 * @returns {Promise<Object>} Trello credentials
 */
const authenticateWithTrello = () => {
  return new Promise((resolve, reject) => {
    // Get API key from store or use default
    const apiKey = store.get('trello.apiKey') || process.env.TRELLO_API_KEY;
    
    if (!apiKey) {
      return reject(new Error('Trello API key not found'));
    }
    
    // Create auth window
    authWindow = new BrowserWindow({
      width: 800,
      height: 600,
      show: true,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true
      }
    });
    
    // Build auth URL
    const authUrl = `https://trello.com/1/authorize?expiration=never&scope=read,write&response_type=token&name=AutoReminder&key=${apiKey}`;
    
    // Load auth URL
    authWindow.loadURL(authUrl);
    
    // Handle redirect
    authWindow.webContents.on('will-navigate', (event, url) => {
      handleCallback(url, resolve, reject);
    });
    
    authWindow.webContents.on('will-redirect', (event, url) => {
      handleCallback(url, resolve, reject);
    });
    
    // Handle window close
    authWindow.on('closed', () => {
      authWindow = null;
      reject(new Error('Authentication window was closed'));
    });
  });
};

/**
 * Handle Trello auth callback
 * @param {string} url - Callback URL
 * @param {Function} resolve - Promise resolve function
 * @param {Function} reject - Promise reject function
 */
const handleCallback = (url, resolve, reject) => {
  if (url.includes('token=')) {
    // Extract token from URL
    const token = url.match(/token=([^&]*)/)[1];
    
    if (token) {
      // Get API key
      const apiKey = store.get('trello.apiKey') || process.env.TRELLO_API_KEY;
      
      // Store credentials
      store.set('trello.token', token);
      
      // Close auth window
      if (authWindow) {
        authWindow.close();
        authWindow = null;
      }
      
      // Resolve with credentials
      resolve({ apiKey, token });
    } else {
      reject(new Error('Failed to extract token from callback URL'));
    }
  }
};

/**
 * Get all boards for the authenticated user
 * @returns {Promise<Array>} List of boards
 */
const getBoards = async () => {
  try {
    const { apiKey, token } = getTrelloCredentials();
    
    if (!apiKey || !token) {
      throw new Error('Trello credentials not found');
    }
    
    const response = await axios.get(`${TRELLO_API_BASE_URL}/members/me/boards`, {
      params: {
        key: apiKey,
        token: token,
        fields: 'name,id'
      }
    });
    
    return response.data;
  } catch (error) {
    log.error('Error getting Trello boards:', error);
    throw error;
  }
};

/**
 * Get cards from a specific board
 * @param {string} boardId - Trello board ID
 * @param {Array<string>} listNames - Names of lists to filter by
 * @returns {Promise<Array>} List of cards
 */
const getCards = async (boardId, listNames = []) => {
  try {
    const { apiKey, token } = getTrelloCredentials();
    
    if (!apiKey || !token) {
      throw new Error('Trello credentials not found');
    }
    
    // Get lists on the board
    const listsResponse = await axios.get(`${TRELLO_API_BASE_URL}/boards/${boardId}/lists`, {
      params: {
        key: apiKey,
        token: token,
        fields: 'name,id'
      }
    });
    
    // Filter lists by name if listNames is provided
    const lists = listNames.length > 0
      ? listsResponse.data.filter(list => listNames.includes(list.name))
      : listsResponse.data;
    
    // Get cards from each list
    const listIds = lists.map(list => list.id);
    
    if (listIds.length === 0) {
      return [];
    }
    
    const cardsResponse = await axios.get(`${TRELLO_API_BASE_URL}/boards/${boardId}/cards`, {
      params: {
        key: apiKey,
        token: token,
        fields: 'name,id,due,desc,url',
        members: true,
        member_fields: 'fullName,username'
      }
    });
    
    // Filter cards by list ID
    return cardsResponse.data.filter(card => listIds.includes(card.idList));
  } catch (error) {
    log.error('Error getting Trello cards:', error);
    throw error;
  }
};

/**
 * Post a comment on a Trello card
 * @param {string} cardId - Trello card ID
 * @param {string} message - Comment message
 * @returns {Promise<Object>} Comment data
 */
const postComment = async (cardId, message) => {
  try {
    const { apiKey, token } = getTrelloCredentials();
    
    if (!apiKey || !token) {
      throw new Error('Trello credentials not found');
    }
    
    const response = await axios.post(`${TRELLO_API_BASE_URL}/cards/${cardId}/actions/comments`, {
      text: message
    }, {
      params: {
        key: apiKey,
        token: token
      }
    });
    
    return response.data;
  } catch (error) {
    log.error('Error posting Trello comment:', error);
    throw error;
  }
};

/**
 * Sync cards from Trello to local database
 * @param {Object} db - Database instance
 * @returns {Promise<Array>} Synced cards
 */
const syncCards = async (db) => {
  try {
    // Get all boards
    const boards = await getBoards();
    
    // Get cards from each board
    let allCards = [];
    
    for (const board of boards) {
      const cards = await getCards(board.id);
      
      // Add board info to each card
      const cardsWithBoard = cards.map(card => ({
        ...card,
        boardName: board.name,
        boardId: board.id
      }));
      
      allCards = [...allCards, ...cardsWithBoard];
    }
    
    // Store cards in database
    if (db) {
      // Implementation depends on database module
      // This will be integrated with the database service
    }
    
    return allCards;
  } catch (error) {
    log.error('Error syncing Trello cards:', error);
    throw error;
  }
};

module.exports = {
  authenticateWithTrello,
  getBoards,
  getCards,
  postComment,
  syncCards
};
